import flet as ft
import cv2
import base64
import threading
import time
import random
import json
from openai import OpenAI
import procesador 
import os

class DaliApp:
    def __init__(self, page: ft.Page):
        self.page = page
        self.client = OpenAI(api_key=os.getenv("OPENAI_API_KEY"))
        self.cap = None
        self.camera_running = False
        self.character_assigned = None
        
        self.personajes = self.cargar_personajes()
        
        # Configuración de Windows
        self.page.title = "Proyecto Dalí - Windows Edition"
        self.page.window_maximized = True
        self.page.theme_mode = ft.ThemeMode.LIGHT
        
        # Rutas de fuentes para Windows (sin la barra inicial /)
        self.page.fonts = {
            "OpenDyslexic": "fonts/OpenDyslexic-Regular.ttf",
            "Atkinson": "fonts/AtkinsonHyperlegibleNext-Regular.ttf"
        }
        self.font_list = ["Atkinson", "OpenDyslexic"]
        self.current_font_index = 0
        
        self.setup_ui()

    def cargar_personajes(self):
        try:
            with open("personajes.json", "r", encoding="utf-8") as f:
                return json.load(f)
        except:
            return {"Hombre": [], "Mujer": []}

    def setup_ui(self):
        # 1. INTRO
        self.intro_view = ft.Container(
            content=ft.Image(src="intro.gif", width=600), 
            alignment=ft.alignment.center, 
            expand=True
        )

        # 2. SELECCIÓN
        self.selection_view = ft.Column(
            controls=[
                ft.TextButton("Cambiar Fuente (Accesibilidad)", on_click=self.toggle_font),
                ft.Text("¿Quién serás hoy?", size=50, weight="bold"),
                ft.Row([
                    ft.ElevatedButton("Hombre", width=250, height=100, on_click=lambda _: self.go_to_camera("Hombre")),
                    ft.ElevatedButton("Mujer", width=250, height=100, on_click=lambda _: self.go_to_camera("Mujer"))
                ], alignment=ft.MainAxisAlignment.CENTER)
            ], alignment=ft.MainAxisAlignment.CENTER, horizontal_alignment=ft.CrossAxisAlignment.CENTER, expand=True, visible=False
        )

        # 3. CÁMARA
        self.img_camara = ft.Image(src="", fit=ft.ImageFit.COVER, expand=True)
        self.cam_status = ft.Text("Iniciando cámara...", color="blue")
        self.lbl_countdown = ft.Text("", size=120, color="red", weight="bold")
        self.btn_capture = ft.ElevatedButton("¡CAPTURAR!", on_click=self.start_countdown, height=60, visible=False)

        self.camera_view = ft.Stack(
            controls=[
                self.img_camara,
                ft.Container(content=ft.Image(src="silueta.png", opacity=0.5), alignment=ft.alignment.center),
                ft.Container(content=self.cam_status, alignment=ft.alignment.top_center, padding=20),
                ft.Container(content=self.lbl_countdown, alignment=ft.alignment.center),
                ft.Container(content=self.btn_capture, alignment=ft.alignment.bottom_center, padding=50)
            ], expand=True, visible=False
        )

        # 4. PROCESAMIENTO
        self.pr = ft.ProgressRing(width=80, height=80)
        self.img_result = ft.Image(src="", visible=False, width=500)
        self.lbl_status = ft.Text("Analizando rostro...", size=20)
        self.btn_draw = ft.ElevatedButton("Enviar a Dibujo", visible=False, bgcolor="green", color="white")

        self.processing_view = ft.Column(
            controls=[self.pr, self.img_result, self.lbl_status, self.btn_draw],
            alignment=ft.MainAxisAlignment.CENTER, horizontal_alignment=ft.CrossAxisAlignment.CENTER, expand=True, visible=False
        )

        self.page.add(self.intro_view, self.selection_view, self.camera_view, self.processing_view)
        self.page.update()
        
        # Iniciar flujo
        threading.Timer(3.0, self.go_to_selection).start()

    def toggle_font(self, e):
        self.current_font_index = (self.current_font_index + 1) % len(self.font_list)
        self.page.theme = ft.Theme(font_family=self.font_list[self.current_font_index])
        self.page.update()

    def go_to_selection(self):
        self.intro_view.visible = False
        self.selection_view.visible = True
        self.page.update()

    def go_to_camera(self, gender):
        if self.personajes[gender]:
            self.character_assigned = random.choice(self.personajes[gender])
        
        self.selection_view.visible = False
        self.camera_view.visible = True
        self.page.update()
        
        self.cap = cv2.VideoCapture(0) # En Windows suele ser 0 o 1
        if self.cap.isOpened():
            self.camera_running = True
            self.cam_status.value = "CÁMARA CONECTADA"
            self.cam_status.color = "green"
            self.btn_capture.visible = True
            threading.Thread(target=self.update_frame, daemon=True).start()
        else:
            self.cam_status.value = "ERROR: No se detecta la cámara Logitech"
            self.cam_status.color = "red"
        self.page.update()

    def update_frame(self):
        while self.camera_running and self.cap.isOpened():
            ret, frame = self.cap.read()
            if ret:
                # Espejo para que el usuario se vea natural
                frame = cv2.flip(frame, 1)
                _, buffer = cv2.imencode('.jpg', frame)
                self.img_camara.src_base64 = base64.b64encode(buffer).decode()
                self.page.update()
            time.sleep(0.03)

    def start_countdown(self, e):
        self.btn_capture.disabled = True
        threading.Thread(target=self.countdown_routine, daemon=True).start()

    def countdown_routine(self):
        for i in range(5, 0, -1):
            self.lbl_countdown.value = str(i)
            self.page.update()
            time.sleep(1)
        self.execute_capture()

    def execute_capture(self):
        self.camera_running = False
        ret, frame = self.cap.read()
        if ret:
            cv2.imwrite("rostro_base.jpg", frame)
        self.cap.release()
        
        self.camera_view.visible = False
        self.processing_view.visible = True
        self.page.update()
        threading.Thread(target=self.call_openai_api, daemon=True).start()

    def call_openai_api(self):
        try:
            nombre = self.character_assigned['nombre']
            historia = self.character_assigned['historia_ia']
            bio_texto = self.character_assigned['bio_display']

            self.lbl_status.value = f"Inspirándome en {nombre}..."
            self.page.update()

            prompt = f"Line art drawing, fine black lines on white background, minimalist. Subject: {nombre}, motifs: {historia}. No shading."
            
            response = self.client.images.generate(model="dall-e-3", prompt=prompt)
            url_img = response.data[0].url
            
            # Ensamblar ficha final
            ruta_final = procesador.ensamblar_ficha(url_img, bio_texto)

            if ruta_final:
                self.img_result.src = ruta_final
                self.lbl_status.value = f"¡Retrato de {nombre} listo!"
                self.pr.visible = False
                self.img_result.visible = True
                self.btn_draw.visible = True
                self.page.update()
        except Exception as e:
            self.lbl_status.value = f"Error: {str(e)}"
            self.pr.visible = False
            self.page.update()

def main(page: ft.Page):
    DaliApp(page)

if __name__ == "__main__":
    ft.app(target=main, assets_dir="assets")