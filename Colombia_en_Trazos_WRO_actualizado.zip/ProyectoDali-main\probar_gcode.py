from pathlib import Path
from gcode_generator import generar_gcode_desde_archivo


BASE_DIR = Path(__file__).resolve().parent

imagen_prueba = BASE_DIR / "assets" / "silueta.png"

salida = generar_gcode_desde_archivo(
    imagen_path=imagen_prueba,
    nombre_salida="prueba_silueta.gcode"
)

print(f"GCode generado en: {salida}")