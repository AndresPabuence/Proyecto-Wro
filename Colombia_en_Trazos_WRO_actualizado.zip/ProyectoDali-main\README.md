# Proyecto Dalí

Proyecto Dalí es una aplicación web local desarrollada con **Python**, **FastAPI**, **HTML**, **CSS**, **JavaScript** y la **API de OpenAI**.  
La aplicación permite seleccionar una cámara disponible en el navegador, capturar una fotografía de una persona y generar una caricatura artística inspirada en un personaje definido en `personajes.json`.

La versión actual usa una arquitectura web local para que el navegador maneje la cámara de forma nativa. Esto mejora la fluidez del video, la selección de cámaras y la estabilidad de la captura.

---

## Características principales

- Interfaz web local ejecutada desde FastAPI.
- Selección de cámara desde un menú desplegable.
- Visualización de video en tiempo real usando el navegador.
- Cuenta regresiva antes de capturar la imagen.
- Captura de fotografía mediante `canvas`.
- Envío de la imagen capturada al backend en Python.
- Generación de caricatura usando la imagen como referencia.
- Selección aleatoria de personaje según la modalidad elegida: `Hombre` o `Mujer`.
- Resultado final mostrado en pantalla con imagen y texto descriptivo.
- Separación clara entre frontend, backend y recursos estáticos.

---

## Estructura del proyecto

```txt
ProyectoDali/
│
├── main.py
├── procesador.py
├── personajes.json
├── requirements.txt
├── .env
├── .env.example
├── .gitignore
├── README.md
│
├── assets/
│   ├── intro.gif
│   └── silueta.png
│
└── static/
    ├── index.html
    ├── styles.css
    ├── app.js
    ├── capturas/
    └── resultados/
```

---

## Descripción de archivos principales

| Archivo | Descripción |
|---|---|
| `main.py` | Backend principal con FastAPI. Expone las rutas web y la API de generación. |
| `procesador.py` | Procesa la captura, guarda la imagen y llama a OpenAI para generar la caricatura. |
| `personajes.json` | Contiene los personajes disponibles y sus motivos visuales. |
| `static/index.html` | Interfaz principal de la aplicación. |
| `static/styles.css` | Estilos visuales de la interfaz. |
| `static/app.js` | Lógica del navegador: cámara, captura, cuenta regresiva y comunicación con el backend. |
| `assets/intro.gif` | Animación o imagen de introducción. |
| `assets/silueta.png` | Guía visual sobrepuesta en la cámara. |
| `.env` | Variables sensibles del entorno local. No debe subirse a GitHub. |
| `.env.example` | Plantilla de configuración para otros usuarios. |

---

## Requisitos previos

Antes de ejecutar el proyecto se recomienda tener instalado:

- Python 3.10 o superior.
- Git.
- Un navegador moderno como Chrome, Edge o Firefox.
- Una cámara web funcional.
- Una API Key activa de OpenAI.

Para verificar la versión de Python:

```bash
python --version
```

---

## Instalación

### 1. Clonar el repositorio

```bash
git clone https://github.com/tu-usuario/tu-repositorio.git
cd tu-repositorio
```

---

### 2. Crear entorno virtual

En Windows:

```powershell
python -m venv .venv
```

Activar el entorno virtual:

```powershell
.venv\Scripts\activate
```

Cuando el entorno esté activo, la terminal debería mostrar algo similar a:

```powershell
(.venv) PS D:\ProyectoDali>
```

---

### 3. Instalar dependencias

```powershell
python -m pip install -r requirements.txt
```

El archivo `requirements.txt` debe contener:

```txt
fastapi
uvicorn[standard]
openai
python-dotenv
Pillow
requests
python-multipart
```

---

## Configuración de variables de entorno

Crea un archivo llamado `.env` en la raíz del proyecto:

```env
OPENAI_API_KEY=tu_api_key_real
OPENAI_IMAGE_MODEL=gpt-image-1
```

Ejemplo:

```env
OPENAI_API_KEY=sk-proj-xxxxxxxxxxxxxxxxxxxxxxxx
OPENAI_IMAGE_MODEL=gpt-image-1
```

> Importante: el archivo `.env` contiene información sensible y no debe subirse al repositorio.

También se recomienda incluir un archivo `.env.example`:

```env
OPENAI_API_KEY=coloca_tu_api_key_aqui
OPENAI_IMAGE_MODEL=gpt-image-1
```

---

## Ejecución del proyecto

Desde la raíz del proyecto, con el entorno virtual activo, ejecuta:

```powershell
python -m uvicorn main:app --reload --host 127.0.0.1 --port 8000
```

Luego abre en el navegador:

```txt
http://127.0.0.1:8000
```

---

## Flujo de uso

1. Se muestra una pantalla inicial con `intro.gif`.
2. La aplicación pasa a la pantalla de selección.
3. El navegador solicita permisos para usar la cámara.
4. Se listan las cámaras disponibles en un menú desplegable.
5. El usuario selecciona una cámara.
6. El usuario elige una modalidad: `Hombre` o `Mujer`.
7. Se muestra el video en tiempo real.
8. El usuario presiona **¡CAPTURAR!**.
9. Se inicia una cuenta regresiva.
10. Se captura la imagen desde el video.
11. La imagen se envía al backend.
12. OpenAI genera una caricatura usando la foto como referencia.
13. Se muestra el resultado final junto con el texto del personaje asignado.

---

## Configuración de personajes

Los personajes se gestionan desde `personajes.json`.

Ejemplo:

```json
{
  "Hombre": [
    {
      "nombre": "Salvador Dalí",
      "historia_ia": "relojes blandos, hormigas, surrealismo, bigotes largos",
      "bio_display": "El genio del surrealismo español."
    }
  ],
  "Mujer": [
    {
      "nombre": "Frida Kahlo",
      "historia_ia": "flores coloridas, monos, cejas marcadas, arte mexicano",
      "bio_display": "Icono del arte y la fortaleza mexicana."
    }
  ]
}
```

Cada personaje debe tener estos campos:

| Campo | Descripción |
|---|---|
| `nombre` | Nombre del personaje artístico o histórico. |
| `historia_ia` | Motivos visuales que se integrarán en la caricatura. |
| `bio_display` | Texto descriptivo que se mostrará con el resultado. |

---

## Recursos gráficos requeridos

La carpeta `assets/` debe contener:

```txt
assets/intro.gif
assets/silueta.png
```

`intro.gif` se muestra al inicio de la experiencia.  
`silueta.png` se usa como guía visual sobre el video de la cámara.

---

## Carpetas generadas

Durante la ejecución se crearán imágenes en:

```txt
static/capturas/
static/resultados/
```

Estas carpetas almacenan:

| Carpeta | Contenido |
|---|---|
| `static/capturas/` | Fotografías capturadas desde la cámara. |
| `static/resultados/` | Caricaturas generadas por OpenAI. |

Estas imágenes son salidas del programa y no deberían subirse al repositorio.

---

## `.gitignore` recomendado

El archivo `.gitignore` debe incluir:

```gitignore
# Entornos virtuales
.venv/
venv/

# Python
__pycache__/
*.pyc
*.pyo
*.pyd

# Variables sensibles
.env

# Capturas y resultados generados
static/capturas/
static/resultados/

# Archivos temporales
rostro_base.jpg
temp_dali.png

# Sistema
.DS_Store
Thumbs.db
```

---

## Problemas frecuentes

### El navegador no muestra cámaras

Revisa que el navegador tenga permiso para acceder a la cámara.  
También verifica que otra aplicación no esté usando la cámara, como Teams, Zoom, OBS o el navegador en otra pestaña.

---

### El menú de cámaras aparece vacío

Prueba presionando el botón **Actualizar cámaras**.  
Si sigue sin aparecer, revisa los permisos del navegador o cambia de navegador.

---

### Error 500 al generar la caricatura

Revisa la consola donde se ejecuta Uvicorn.  
El backend imprime detalles del error en la ruta:

```txt
POST /api/generar
```

Causas comunes:

- API Key inválida.
- Falta de saldo o acceso al modelo configurado.
- Modelo incorrecto en `.env`.
- Imagen capturada en formato no válido.
- Error de conexión con OpenAI.

---

### Error: no se encontró `OPENAI_API_KEY`

Verifica que el archivo `.env` exista en la raíz del proyecto y que tenga esta estructura:

```env
OPENAI_API_KEY=tu_api_key_real
OPENAI_IMAGE_MODEL=gpt-image-1
```

---

### El resultado no se parece suficientemente a la persona

La aplicación envía la imagen capturada como referencia y solicita conservar rasgos faciales.  
Sin embargo, el parecido puede variar según:

- La calidad de iluminación.
- La posición del rostro.
- La resolución de la cámara.
- La claridad de la captura.
- El modelo de imagen usado.
- El prompt definido en `procesador.py`.

Para mejorar el parecido se recomienda:

- Usar buena iluminación frontal.
- Centrar el rostro dentro de la silueta.
- Evitar fondos muy cargados.
- Capturar a la persona mirando hacia la cámara.
- Probar ajustes en el prompt de `procesador.py`.

---

## Comandos útiles de desarrollo

Ejecutar servidor:

```powershell
python -m uvicorn main:app --reload --host 127.0.0.1 --port 8000
```

Instalar dependencias:

```powershell
python -m pip install -r requirements.txt
```

Ver estado de Git:

```powershell
git status
```

Agregar cambios seguros:

```powershell
git add main.py procesador.py requirements.txt personajes.json README.md .gitignore .env.example
git add static/index.html static/styles.css static/app.js
git add assets/intro.gif assets/silueta.png
```

Crear commit:

```powershell
git commit -m "Actualiza version web de Proyecto Dali"
```

Subir cambios:

```powershell
git push
```

---

## Seguridad

Nunca subas el archivo `.env` al repositorio.

Si accidentalmente subiste `.env`, elimínalo del seguimiento de Git:

```powershell
git rm --cached .env
git add .gitignore
git commit -m "Elimina archivo env del repositorio"
git push
```

Después de eso, se recomienda regenerar la API Key desde la plataforma de OpenAI.

---

## Estado actual

Esta versión reemplaza el prototipo anterior en Flet por una arquitectura web local:

```txt
FastAPI + HTML + CSS + JavaScript + OpenAI
```

La cámara se gestiona desde el navegador usando `getUserMedia()`, lo que permite video fluido y selección de dispositivos sin depender de OpenCV para la visualización en tiempo real.

---

## Autor

Proyecto desarrollado como una experiencia educativa, artística e interactiva basada en inteligencia artificial, accesibilidad y creación visual.