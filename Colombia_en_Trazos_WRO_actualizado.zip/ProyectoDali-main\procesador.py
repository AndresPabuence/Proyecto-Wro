from __future__ import annotations

import base64
import os
import re
import time
from pathlib import Path
from typing import Any, NotRequired, TypedDict

from dotenv import load_dotenv
from openai import OpenAI
from PIL import Image


BASE_DIR = Path(__file__).resolve().parent
STATIC_DIR = BASE_DIR / "static"
CAPTURAS_DIR = STATIC_DIR / "capturas"
RESULTADOS_DIR = STATIC_DIR / "resultados"

load_dotenv(BASE_DIR / ".env")


class Personaje(TypedDict):
    nombre: str
    historia_ia: str
    bio_display: str
    categoria: NotRequired[str]
    region: NotRequired[str]
    dato_cultural: NotRequired[str]


def guardar_captura_desde_data_url(image_data: str) -> str:
    """
    Recibe una imagen en formato data URL:
    data:image/png;base64,...
    La guarda como PNG dentro de static/capturas.
    Retorna la ruta relativa respecto a static.
    """
    CAPTURAS_DIR.mkdir(parents=True, exist_ok=True)

    patron = r"^data:image\/(png|jpeg|jpg);base64,(.+)$"
    match = re.match(patron, image_data)

    if match is None:
        raise ValueError("La imagen recibida no tiene formato base64 válido.")

    contenido_base64 = match.group(2)
    image_bytes = base64.b64decode(contenido_base64)

    nombre_archivo = f"captura_{int(time.time() * 1000)}.png"
    ruta_salida = CAPTURAS_DIR / nombre_archivo
    ruta_temporal = CAPTURAS_DIR / f"temp_{nombre_archivo}"

    ruta_temporal.write_bytes(image_bytes)

    try:
        with Image.open(ruta_temporal) as img:
            imagen_rgb = img.convert("RGB")
            imagen_rgb.save(ruta_salida, format="PNG")
    finally:
        ruta_temporal.unlink(missing_ok=True)

    return f"capturas/{nombre_archivo}"


def construir_prompt(personaje: Personaje) -> str:
    nombre = personaje["nombre"]
    historia = personaje["historia_ia"]
    categoria = personaje.get("categoria", "cultura colombiana")
    region = personaje.get("region", "Colombia")
    dato_cultural = personaje.get("dato_cultural", "")

    return f"""
Crea una caricatura artística basada en la persona de la fotografía de referencia.

Prioridad principal:
- Mantener un parecido claro con la persona fotografiada.
- Conservar rasgos reconocibles: forma del rostro, expresión general, gafas si las tiene,
  proporciones faciales, tipo de cabeza, cejas, ojos, nariz, boca y rasgos principales.
- No cambiar la identidad visual de la persona.

Estilo visual:
- Caricatura amable, limpia y profesional.
- Dibujo artístico de línea clara.
- Fondo blanco o muy claro.
- Composición centrada tipo retrato.
- Apto para una experiencia educativa e infantil.

Inspiración artística:
- El personaje asignado es {nombre}.
- Categoría cultural: {categoria}.
- Región o contexto colombiano: {region}.
- Dato cultural para inspirar detalles visuales: {dato_cultural}.
- Integra de manera sutil estos motivos visuales: {historia}.
- Los motivos deben acompañar la caricatura, pero el rostro de la persona debe seguir siendo reconocible.

Evita:
- Convertir a la persona completamente en {nombre}.
- Cambiar demasiado la edad, la forma del rostro o los rasgos principales.
- Crear una imagen genérica sin parecido con la foto.
""".strip()


def extraer_base64_resultado(resultado: Any) -> str:
    data = getattr(resultado, "data", None)

    if not data:
        raise RuntimeError("OpenAI no devolvió datos de imagen.")

    primera_imagen = data[0]
    image_base64 = getattr(primera_imagen, "b64_json", None)

    if not isinstance(image_base64, str) or not image_base64:
        raise RuntimeError("OpenAI no devolvió imagen en base64.")

    return image_base64


def llamar_openai_edit(
    client: Any,
    modelo: str,
    captura_path: Path,
    prompt: str,
) -> Any:
    """
    Llama al endpoint de edición con varios respaldos.
    Algunos modelos aceptan parámetros distintos.
    """

    # gpt-image-2 procesa inputs en alta fidelidad automáticamente y no permite
    # cambiar input_fidelity. Para los demás se intenta usar alta fidelidad.
    # La documentación indica que gpt-image-2 no admite cambiar input_fidelity,
    # porque procesa entradas de imagen en alta fidelidad automáticamente.
    with captura_path.open("rb") as imagen:
        parametros: dict[str, Any] = {
            "model": modelo,
            "image": imagen,
            "prompt": prompt,
            "size": "1024x1024",
            "quality": "medium",
            "n": 1,
            "output_format": "png",
        }

        if modelo != "gpt-image-2":
            parametros["input_fidelity"] = "high"

        try:
            return client.images.edit(**parametros)
        except Exception as primer_error:
            print(f"Primer intento con parámetros completos falló: {primer_error}")

    # Segundo intento: sin input_fidelity.
    with captura_path.open("rb") as imagen:
        parametros_sin_fidelidad: dict[str, Any] = {
            "model": modelo,
            "image": imagen,
            "prompt": prompt,
            "size": "1024x1024",
            "quality": "medium",
            "n": 1,
            "output_format": "png",
        }

        try:
            return client.images.edit(**parametros_sin_fidelidad)
        except Exception as segundo_error:
            print(f"Segundo intento sin input_fidelity falló: {segundo_error}")

    # Tercer intento: mínimo.
    with captura_path.open("rb") as imagen:
        parametros_minimos: dict[str, Any] = {
            "model": modelo,
            "image": imagen,
            "prompt": prompt,
        }

        try:
            return client.images.edit(**parametros_minimos)
        except Exception as tercer_error:
            print(f"Tercer intento mínimo falló: {tercer_error}")
            raise


def generar_caricatura_con_referencia(
    captura_relativa: str,
    personaje: Personaje,
) -> str:
    """
    Genera una caricatura usando la foto capturada como referencia.
    Retorna la ruta relativa respecto a static.
    """
    RESULTADOS_DIR.mkdir(parents=True, exist_ok=True)

    api_key = os.getenv("OPENAI_API_KEY")

    if not api_key:
        raise RuntimeError("No se encontró OPENAI_API_KEY en .env")

    # Usa gpt-image-1 como valor seguro. Puedes cambiar a gpt-image-1.5 o gpt-image-2
    # si tu cuenta/proyecto ya tiene acceso y verificación.
    modelo = os.getenv("OPENAI_IMAGE_MODEL", "gpt-image-1")

    client: Any = OpenAI(api_key=api_key)

    captura_path = STATIC_DIR / captura_relativa

    if not captura_path.exists():
        raise FileNotFoundError(f"No existe la captura: {captura_path}")

    prompt = construir_prompt(personaje)

    resultado = llamar_openai_edit(
        client=client,
        modelo=modelo,
        captura_path=captura_path,
        prompt=prompt,
    )

    image_base64 = extraer_base64_resultado(resultado)
    image_bytes = base64.b64decode(image_base64)

    nombre_archivo = f"resultado_{int(time.time() * 1000)}.png"
    ruta_resultado = RESULTADOS_DIR / nombre_archivo
    ruta_resultado.write_bytes(image_bytes)

    return f"resultados/{nombre_archivo}"
