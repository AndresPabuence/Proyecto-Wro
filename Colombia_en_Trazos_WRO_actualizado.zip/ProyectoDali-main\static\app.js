const introScreen = document.getElementById("intro-screen");
const selectionScreen = document.getElementById("selection-screen");
const cameraScreen = document.getElementById("camera-screen");
const processingScreen = document.getElementById("processing-screen");
const resultScreen = document.getElementById("result-screen");

const cameraSelect = document.getElementById("camera-select");
const refreshCamerasButton = document.getElementById("refresh-cameras");
const cameraStatus = document.getElementById("camera-status");
const voiceCommandButton = document.getElementById("voice-command-button");
const voiceStopButton = document.getElementById("voice-stop-button");
const voiceStatus = document.getElementById("voice-status");
const voiceTranscript = document.getElementById("voice-transcript");
const lastGcodeButton = document.getElementById("last-gcode-button");
const demoWroButton = document.getElementById("demo-wro-button");
const museumModeButton = document.getElementById("museum-mode-button");
const spinButton = document.getElementById("spin-button");
const continueButton = document.getElementById("continue-button");
const missionButtons = document.getElementById("mission-buttons");
const regionMap = document.getElementById("region-map");
const filterStatus = document.getElementById("filter-status");
const rouletteName = document.getElementById("roulette-name");
const rouletteMeta = document.getElementById("roulette-meta");
const rouletteBio = document.getElementById("roulette-bio");
const rouletteFact = document.getElementById("roulette-fact");
const rouletteWheel = document.getElementById("roulette-wheel");
const rouletteMarkers = document.getElementById("roulette-markers");
const rouletteCenter = document.getElementById("roulette-center");
const museumCard = document.getElementById("museum-card");
const museumTitle = document.getElementById("museum-title");
const museumCategory = document.getElementById("museum-category");
const museumRegion = document.getElementById("museum-region");
const museumMission = document.getElementById("museum-mission");
const museumImpact = document.getElementById("museum-impact");
const audioTestButton = document.getElementById("audio-test-button");
const audioStoryButton = document.getElementById("audio-story-button");
const stopAudioButton = document.getElementById("stop-audio-button");
const audioStatus = document.getElementById("audio-status");
const paperSizeSelect = document.getElementById("paper-size");
const penModeSelect = document.getElementById("pen-mode");
const feedrateRange = document.getElementById("feedrate-range");
const feedrateValue = document.getElementById("feedrate-value");
const accessibilityModeSelect = document.getElementById("accessibility-mode");

const video = document.getElementById("video");
const cameraLabel = document.getElementById("camera-label");
const captureButton = document.getElementById("capture-button");
const countdownEl = document.getElementById("countdown");
const canvas = document.getElementById("capture-canvas");

const processingText = document.getElementById("processing-text");
const processingTimeline = document.getElementById("processing-timeline");
const resultImage = document.getElementById("result-image");
const resultTitle = document.getElementById("result-title");
const resultBio = document.getElementById("result-bio");
const gcodeStats = document.getElementById("gcode-stats");
const gcodePreview = document.getElementById("gcode-preview");
const gcodeTrace = document.getElementById("gcode-trace");
const processSteps = document.getElementById("process-steps");
const robotSim = document.getElementById("robot-sim");
const robotBar = document.getElementById("robot-bar");
const robotStatus = document.getElementById("robot-status");
const robotPercent = document.getElementById("robot-percent");
const culturalPassport = document.getElementById("cultural-passport");
const passportCharacter = document.getElementById("passport-character");
const passportRegion = document.getElementById("passport-region");
const passportMode = document.getElementById("passport-mode");
const passportQr = document.getElementById("passport-qr");
const passportQrLink = document.getElementById("passport-qr-link");
const accessibilityNote = document.getElementById("accessibility-note");
const restartButton = document.getElementById("restart-button");

let currentStream = null;
let selectedGender = null;
let selectedCharacter = null;
let allCharacters = [];
let wheelRotation = 0;
let robotAnimationFrame = null;
let experienceRunId = 0;
let selectedMission = "sorpresa";
let selectedRegion = "todo";
let museumModeRunning = false;
let audioContext = null;
let voiceList = [];
let activeSoundNodes = [];
let speechRecognition = null;
let isVoiceListening = false;
let voiceCommandBusy = false;
let lastVoiceCommand = "";
let lastVoiceCommandAt = 0;

const VOICE_RESUME_DELAY_MS = 3000;

const rouletteColors = [
  "#facc15",
  "#f59e0b",
  "#2563eb",
  "#1d4ed8",
  "#dc2626",
  "#b91c1c",
];

const missionLabels = {
  sorpresa: "Sorpresa",
  musica: "Música",
  arte: "Arte",
  historia: "Historia",
  ciencia: "Ciencia",
  deporte: "Deporte",
};

const accessibilityLabels = {
  normal: "Trazo normal",
  high_contrast: "Alto contraste",
  relief: "Relieve táctil",
};

function showScreen(screen) {
  [introScreen, selectionScreen, cameraScreen, processingScreen, resultScreen].forEach((item) => {
    item.classList.remove("active");
  });

  screen.classList.add("active");
}

function setProcessingStage(activeIndex) {
  if (!processingTimeline) {
    return;
  }

  Array.from(processingTimeline.children).forEach((item, index) => {
    item.classList.toggle("active", index <= activeIndex);
  });
}

function sleep(ms) {
  return new Promise((resolve) => setTimeout(resolve, ms));
}

function buildCulturalStory(personaje = selectedCharacter) {
  if (!personaje) {
    return "Todavía no hay personaje. Dale a la ruleta y dejemos que Colombia decida la inspiración de hoy.";
  }

  const missionLabel = missionLabels[selectedMission] || "Sorpresa";
  const category = personaje.categoria || "cultura colombiana";
  const region = personaje.region || "Colombia";
  const fact = personaje.dato_cultural || "su aporte hace parte de la memoria cultural colombiana";

  return `Listo, la ruleta habló. Hoy tu obra se conecta con ${personaje.nombre}, una figura clave de ${category} en ${region}. ${personaje.bio_display} Dato poderoso: ${fact}. Ahora viene lo bueno: tu rostro entra a la inteligencia artificial, la historia colombiana marca el estilo, OpenCV encuentra los trazos importantes y el robot los convierte en movimiento real. Misión ${missionLabel}: transformar cultura en una pieza que se puede ver, dibujar y tocar.`;
}

function setAudioStatus(message) {
  if (audioStatus) {
    audioStatus.textContent = message;
  }
}

function getAudioContext() {
  const AudioContextClass = window.AudioContext || window.webkitAudioContext;

  if (!AudioContextClass) {
    setAudioStatus("Este navegador no permite sonidos Web Audio.");
    return null;
  }

  if (!audioContext) {
    audioContext = new AudioContextClass();
  }

  if (audioContext.state === "suspended") {
    audioContext.resume().catch((error) => {
      console.warn(error);
      setAudioStatus("Haz clic en Probar sonido para activar el audio.");
    });
  }

  return audioContext;
}

function trackSoundNode(node) {
  activeSoundNodes.push(node);
  node.addEventListener("ended", () => {
    activeSoundNodes = activeSoundNodes.filter((item) => item !== node);
  });
}

function playTone(frequency, delay = 0, duration = 0.22, options = {}) {
  const ctx = getAudioContext();

  if (!ctx) {
    return;
  }

  const start = ctx.currentTime + delay;
  const oscillator = ctx.createOscillator();
  const gain = ctx.createGain();
  const filter = ctx.createBiquadFilter();
  const volume = options.volume ?? 0.12;

  oscillator.type = options.type || "triangle";
  oscillator.frequency.setValueAtTime(frequency, start);

  if (options.slideTo) {
    oscillator.frequency.exponentialRampToValueAtTime(options.slideTo, start + duration);
  }

  filter.type = "lowpass";
  filter.frequency.setValueAtTime(options.filter ?? 2400, start);

  gain.gain.setValueAtTime(0.0001, start);
  gain.gain.exponentialRampToValueAtTime(volume, start + 0.025);
  gain.gain.exponentialRampToValueAtTime(0.0001, start + duration);

  oscillator.connect(filter);
  filter.connect(gain);
  gain.connect(ctx.destination);

  trackSoundNode(oscillator);
  oscillator.start(start);
  oscillator.stop(start + duration + 0.05);
}

function playButtonSound() {
  playTone(660, 0, 0.08, { volume: 0.055, filter: 1800 });
  playTone(990, 0.055, 0.12, { volume: 0.04, filter: 2300 });
}

function playRouletteTick(index = 0) {
  const notes = [523.25, 587.33, 659.25, 783.99, 880];
  const frequency = notes[index % notes.length];
  playTone(frequency, 0, 0.055, { volume: 0.065, type: "square", filter: 1700 });
}

function playRouletteStartSound() {
  setAudioStatus("Ruleta sonando...");
  playTone(293.66, 0, 0.2, { volume: 0.08, slideTo: 587.33, filter: 1800 });
  playTone(440, 0.08, 0.18, { volume: 0.055, slideTo: 880, filter: 2100 });
}

function playRouletteWinSound() {
  setAudioStatus("Personaje elegido. Puedes escuchar la historia.");
  [523.25, 659.25, 783.99, 1046.5].forEach((frequency, index) => {
    playTone(frequency, index * 0.09, 0.25, { volume: 0.09, filter: 2600 });
  });
}

function playProcessSound(index = 0) {
  const baseNotes = [392, 493.88, 587.33, 659.25, 783.99];
  playTone(baseNotes[index % baseNotes.length], 0, 0.16, { volume: 0.055, filter: 1900 });
}

function playSuccessSound() {
  const notes = [523.25, 659.25, 783.99, 1046.5, 1318.51];
  notes.forEach((frequency, index) => {
    playTone(frequency, index * 0.075, 0.28, { volume: 0.085, filter: 2800 });
  });
  playTone(392, 0.09, 0.46, { volume: 0.05, type: "sine", filter: 1600 });
  setAudioStatus("Resultado listo con sonido de celebracion.");
}

function playCountdownSound(number) {
  const frequency = number === 1 ? 880 : 440 + number * 35;
  playTone(frequency, 0, 0.13, { volume: 0.07, filter: 1800 });
}

function playCameraSound() {
  playTone(1000, 0, 0.055, { volume: 0.075, type: "square", filter: 3000 });
  playTone(520, 0.065, 0.09, { volume: 0.05, type: "triangle", filter: 1800 });
}

function playAudioPreview() {
  getAudioContext();
  setAudioStatus("Probando voz de presentador...");
  [392, 523.25, 659.25, 783.99, 1046.5].forEach((frequency, index) => {
    playTone(frequency, index * 0.1, 0.25, { volume: 0.09, filter: 2600 });
  });
  setTimeout(() => {
    speakText(
      "Colombia en Trazos está lista. La cultura entra a la ruleta, la inteligencia artificial crea la obra, OpenCV la vuelve camino y el robot la dibuja en vivo.",
      0,
      { rate: 1.02, pitch: 1.14, status: "Probando voz de presentador..." }
    );
  }, 650);
}

function refreshVoices() {
  if (!("speechSynthesis" in window)) {
    voiceList = [];
    return voiceList;
  }

  voiceList = window.speechSynthesis.getVoices();
  return voiceList;
}

function getSpanishVoice() {
  const voices = voiceList.length ? voiceList : refreshVoices();

  const spanishVoices = voices.filter((voice) => voice.lang.toLowerCase().startsWith("es"));

  if (spanishVoices.length === 0) {
    return null;
  }

  return spanishVoices
    .map((voice) => {
      const name = voice.name.toLowerCase();
      const lang = voice.lang.toLowerCase();
      let score = 0;

      if (lang === "es-co") score += 60;
      if (lang === "es-mx" || lang === "es-us" || lang === "es-es") score += 40;
      if (name.includes("google")) score += 28;
      if (name.includes("microsoft")) score += 24;
      if (name.includes("neural") || name.includes("natural")) score += 20;
      if (name.includes("pablo") || name.includes("helena") || name.includes("sabina")) score += 12;

      return { voice, score };
    })
    .sort((a, b) => b.score - a.score)[0].voice;
}

function speakText(text, retry = 0, options = {}) {
  if (retry === 0) {
    playButtonSound();
  }

  if (!("speechSynthesis" in window) || typeof SpeechSynthesisUtterance === "undefined") {
    setAudioStatus("La voz no esta disponible, pero los efectos de sonido si.");
    return false;
  }

  const voices = refreshVoices();

  if (voices.length === 0 && retry < 2) {
    setAudioStatus("Cargando voces del navegador...");
    setTimeout(() => speakText(text, retry + 1, options), 350);
    return false;
  }

  window.speechSynthesis.cancel();

  const utterance = new SpeechSynthesisUtterance(text);
  const voice = getSpanishVoice();

  if (voice) {
    utterance.voice = voice;
    utterance.lang = voice.lang;
  } else {
    utterance.lang = "es-CO";
  }

  utterance.volume = 1;
  utterance.rate = options.rate ?? 1.01;
  utterance.pitch = options.pitch ?? 1.12;
  utterance.onstart = () => setAudioStatus(options.status || "Narrando historia cultural con modo presentador...");
  utterance.onend = () => {
    setAudioStatus("Historia terminada.");
    if (typeof options.onend === "function") {
      options.onend();
    }
  };
  utterance.onerror = () => {
    setAudioStatus("No sono la voz. Prueba Chrome/Edge y revisa el volumen del equipo.");
    if (typeof options.onerror === "function") {
      options.onerror();
    }
  };

  window.speechSynthesis.speak(utterance);
  setTimeout(() => window.speechSynthesis.resume(), 120);
  return true;
}

function speakTextAndWait(text, options = {}, fallbackMs = 7000) {
  return new Promise((resolve) => {
    let finished = false;
    const finish = () => {
      if (finished) {
        return;
      }

      finished = true;
      resolve();
    };

    const started = speakText(text, 0, {
      ...options,
      onend: finish,
      onerror: finish,
    });

    setTimeout(finish, fallbackMs);
  });
}

function speakSelectedCharacter() {
  speakText(buildCulturalStory(selectedCharacter), 0, {
    rate: 1.02,
    pitch: 1.13,
    status: "Contando la historia con más energía...",
  });
}

function stopAudio() {
  if ("speechSynthesis" in window) {
    window.speechSynthesis.cancel();
  }

  activeSoundNodes.forEach((node) => {
    try {
      node.stop();
    } catch (error) {
      // The oscillator may have already ended.
    }
  });
  activeSoundNodes = [];
  setAudioStatus("Audio detenido.");
}

async function requestInitialPermission() {
  try {
    const stream = await navigator.mediaDevices.getUserMedia({
      video: true,
      audio: false,
    });

    stream.getTracks().forEach((track) => track.stop());
    return true;
  } catch (error) {
    console.error(error);
    cameraStatus.textContent = "No fue posible acceder a la cámara. Revisa permisos del navegador.";
    return false;
  }
}

async function loadCameras() {
  cameraStatus.textContent = "Buscando cámaras disponibles...";
  refreshCamerasButton.disabled = true;

  try {
    const hasPermission = await requestInitialPermission();

    if (!hasPermission) {
      return;
    }

    const devices = await navigator.mediaDevices.enumerateDevices();
    const cameras = devices.filter((device) => device.kind === "videoinput");

    cameraSelect.innerHTML = "";

    if (cameras.length === 0) {
      const option = document.createElement("option");
      option.value = "";
      option.textContent = "No se encontraron cámaras";
      cameraSelect.appendChild(option);
      cameraStatus.textContent = "No se encontraron cámaras disponibles.";
      return;
    }

    cameras.forEach((camera, index) => {
      const option = document.createElement("option");
      option.value = camera.deviceId;
      option.textContent = camera.label || `Cámara ${index + 1}`;
      cameraSelect.appendChild(option);
    });

    cameraStatus.textContent = `Se encontraron ${cameras.length} cámara(s). Selecciona una para continuar.`;
  } catch (error) {
    console.error(error);
    cameraStatus.textContent = "Error al listar cámaras.";
  } finally {
    refreshCamerasButton.disabled = false;
  }
}

async function loadCharacters() {
  const response = await fetch("/api/personajes");
  const data = await response.json();

  if (!response.ok) {
    throw new Error(data.detail || "No fue posible cargar los personajes.");
  }

  allCharacters = [
    ...(data.Hombre || []).map((personaje) => ({ ...personaje, gender: "Hombre" })),
    ...(data.Mujer || []).map((personaje) => ({ ...personaje, gender: "Mujer" })),
  ];

  if (allCharacters.length === 0) {
    throw new Error("No hay personajes configurados para la ruleta.");
  }

  updateFilterStatus();
  renderRouletteWheel();
}

function shortName(name) {
  return name
    .split(" ")
    .filter(Boolean)
    .slice(0, 2)
    .join(" ");
}

function normalizeText(value) {
  return String(value || "")
    .normalize("NFD")
    .replace(/[\u0300-\u036f]/g, "")
    .toLowerCase();
}

function setVoiceStatus(message, state = "idle") {
  if (voiceStatus) {
    voiceStatus.textContent = message;
    voiceStatus.dataset.state = state;
  }
}

function setVoiceTranscript(message) {
  if (voiceTranscript) {
    voiceTranscript.textContent = message || "Esperando comando...";
  }
}

function voiceFeedback(message, state = "ok") {
  setVoiceStatus(message, state);
  playButtonSound();
}

function commandIncludes(command, words) {
  return words.some((word) => command.includes(word));
}

function applyVoiceMission(mission) {
  selectedMission = mission;
  selectedCharacter = null;
  selectedGender = null;
  refreshCulturalFilters();
  voiceFeedback(`Misión ${missionLabels[mission] || mission} activada.`);
}

function applyVoiceRegion(region) {
  selectedRegion = region;
  selectedCharacter = null;
  selectedGender = null;
  refreshCulturalFilters();
  const regionLabel = region === "todo"
    ? "Colombia completa"
    : regionMap?.querySelector(`[data-region="${region}"]`)?.textContent || region;
  voiceFeedback(`Región ${regionLabel} activada.`);
}

function applyVoiceAccessibility(mode) {
  accessibilityModeSelect.value = mode;
  syncMachineControls();
  const label = accessibilityLabels[mode] || "Trazo normal";
  voiceFeedback(`Modo ${label} activado.`);
}

function applyVoicePaper(size) {
  paperSizeSelect.value = size;
  syncMachineControls();
  voiceFeedback(`Área de dibujo ${size.replace("x", " por ")} milímetros.`);
}

function getSpeechRecognition() {
  if (speechRecognition) {
    return speechRecognition;
  }

  const RecognitionClass = window.SpeechRecognition || window.webkitSpeechRecognition;

  if (!RecognitionClass) {
    setVoiceStatus("Este navegador no soporta reconocimiento de voz. Prueba Chrome o Edge.", "error");
    return null;
  }

  speechRecognition = new RecognitionClass();
  speechRecognition.lang = "es-CO";
  speechRecognition.continuous = true;
  speechRecognition.interimResults = true;
  speechRecognition.maxAlternatives = 1;

  speechRecognition.onstart = () => {
    setVoiceStatus("Escuchando... di un comando.", "listening");
    voiceCommandButton.disabled = true;
    voiceStopButton.disabled = false;
  };

  speechRecognition.onresult = (event) => {
    let interimTranscript = "";
    let finalTranscript = "";

    for (let index = event.resultIndex; index < event.results.length; index++) {
      const transcript = event.results[index][0].transcript.trim();

      if (event.results[index].isFinal) {
        finalTranscript += ` ${transcript}`;
      } else {
        interimTranscript += ` ${transcript}`;
      }
    }

    if (interimTranscript.trim()) {
      setVoiceTranscript(`Escuchando: ${interimTranscript.trim()}`);
    }

    if (finalTranscript.trim()) {
      handleVoiceCommand(finalTranscript.trim());
    }
  };

  speechRecognition.onerror = (event) => {
    if (event.error === "not-allowed" || event.error === "service-not-allowed") {
      isVoiceListening = false;
      voiceCommandButton.disabled = false;
      voiceStopButton.disabled = true;
      setVoiceStatus("Permiso de micrófono bloqueado. Actívalo en el navegador.", "error");
      return;
    }

    if (event.error === "no-speech") {
      setVoiceStatus("No escuché nada. Intenta hablar más cerca del micrófono.", "idle");
      return;
    }

    setVoiceStatus(`Error de voz: ${event.error}.`, "error");
  };

  speechRecognition.onend = () => {
    if (!isVoiceListening) {
      voiceCommandButton.disabled = false;
      voiceStopButton.disabled = true;
      return;
    }

    setTimeout(() => {
      try {
        speechRecognition.start();
      } catch (error) {
        console.warn(error);
      }
    }, 350);
  };

  return speechRecognition;
}

function startVoiceListening() {
  const recognition = getSpeechRecognition();

  if (!recognition) {
    return;
  }

  isVoiceListening = true;
  setVoiceTranscript("Esperando comando...");
  setVoiceStatus("Activando micrófono...", "listening");

  try {
    recognition.start();
  } catch (error) {
    if (error.name !== "InvalidStateError") {
      console.warn(error);
      setVoiceStatus("No pude activar el micrófono.", "error");
    }
  }
}

function stopVoiceListening(showMessage = true) {
  isVoiceListening = false;

  if (speechRecognition) {
    try {
      speechRecognition.stop();
    } catch (error) {
      console.warn(error);
    }
  }

  voiceCommandButton.disabled = false;
  voiceStopButton.disabled = true;

  if (showMessage) {
    setVoiceStatus("Control por voz detenido.", "idle");
  }
}

function resumeVoiceListeningWhenQuiet(delayMs = VOICE_RESUME_DELAY_MS) {
  setVoiceStatus("Esperando silencio antes de activar el micrófono...", "idle");

  function waitForNarratorToFinish() {
    const narratorIsSpeaking = "speechSynthesis" in window
      && (window.speechSynthesis.speaking || window.speechSynthesis.pending);

    if (narratorIsSpeaking) {
      setTimeout(waitForNarratorToFinish, 500);
      return;
    }

    setVoiceStatus(`Pausa de ${Math.round(delayMs / 1000)} segundos para evitar escuchar la narración...`, "idle");

    setTimeout(() => {
      const narratorStartedAgain = "speechSynthesis" in window
        && (window.speechSynthesis.speaking || window.speechSynthesis.pending);

      if (narratorStartedAgain) {
        waitForNarratorToFinish();
        return;
      }

      if (!cameraScreen.classList.contains("active") && !isVoiceListening) {
        startVoiceListening();
      }
    }, delayMs);
  }

  waitForNarratorToFinish();
}

function handleVoiceCommand(transcript) {
  const command = normalizeText(transcript).replace(/[^\w\s]/g, " ").replace(/\s+/g, " ").trim();
  const now = Date.now();

  setVoiceTranscript(`Dijiste: ${transcript}`);

  if (!command || (command === lastVoiceCommand && now - lastVoiceCommandAt < 1200)) {
    return;
  }

  lastVoiceCommand = command;
  lastVoiceCommandAt = now;
  executeVoiceCommand(command);
}

async function executeVoiceCommand(command) {
  if (voiceCommandBusy) {
    return;
  }

  voiceCommandBusy = true;

  try {
    if (commandIncludes(command, ["ayuda", "comandos", "que puedo decir"])) {
      setVoiceStatus("Puedes decir: gira la ruleta, quiero música, Caribe, modo museo, demo WRO, escuchar historia, continuar o capturar.", "ok");
      return;
    }

    if (commandIncludes(command, ["detener voz", "parar voz", "dejar de escuchar"])) {
      stopVoiceListening();
      return;
    }

    if (commandIncludes(command, ["detener audio", "parar audio", "silencio", "callate"])) {
      stopAudio();
      setVoiceStatus("Audio detenido por comando de voz.", "ok");
      return;
    }

    if (commandIncludes(command, ["probar voz", "prueba voz", "probar sonido", "prueba sonido"])) {
      stopVoiceListening(false);
      playAudioPreview();
      setVoiceStatus("Probando voz y sonido.", "ok");
      return;
    }

    if (commandIncludes(command, ["escuchar historia", "leer historia", "historia del personaje", "cuentame la historia"])) {
      if (!selectedCharacter) {
        setVoiceStatus("Primero gira la ruleta para escoger personaje.", "error");
        return;
      }

      setVoiceStatus("Reproduciendo historia del personaje.", "ok");
      stopVoiceListening(false);
      speakSelectedCharacter();
      return;
    }

    if (commandIncludes(command, ["musica", "musical"])) {
      applyVoiceMission("musica");
      return;
    }

    if (commandIncludes(command, ["arte", "pintura", "literatura"])) {
      applyVoiceMission("arte");
      return;
    }

    if (commandIncludes(command, ["historia", "historico", "liderazgo"])) {
      applyVoiceMission("historia");
      return;
    }

    if (commandIncludes(command, ["ciencia", "tecnologia", "nasa"])) {
      applyVoiceMission("ciencia");
      return;
    }

    if (commandIncludes(command, ["deporte", "deportes"])) {
      applyVoiceMission("deporte");
      return;
    }

    if (commandIncludes(command, ["sorpresa", "aleatorio"])) {
      applyVoiceMission("sorpresa");
      return;
    }

    if (commandIncludes(command, ["caribe", "costa"])) {
      applyVoiceRegion("caribe");
      return;
    }

    if (commandIncludes(command, ["andina", "andes", "bogota", "medellin"])) {
      applyVoiceRegion("andina");
      return;
    }

    if (commandIncludes(command, ["pacifico", "choco", "cali"])) {
      applyVoiceRegion("pacifico");
      return;
    }

    if (commandIncludes(command, ["amazonia", "amazonas"])) {
      applyVoiceRegion("amazonia");
      return;
    }

    if (commandIncludes(command, ["orinoquia", "llanos", "llanera"])) {
      applyVoiceRegion("orinoquia");
      return;
    }

    if (commandIncludes(command, ["colombia completa", "toda colombia", "todo colombia"])) {
      applyVoiceRegion("todo");
      return;
    }

    if (commandIncludes(command, ["relieve", "tactil"])) {
      applyVoiceAccessibility("relief");
      return;
    }

    if (commandIncludes(command, ["alto contraste", "contraste"])) {
      applyVoiceAccessibility("high_contrast");
      return;
    }

    if (commandIncludes(command, ["trazo normal", "modo normal"])) {
      applyVoiceAccessibility("normal");
      return;
    }

    if (commandIncludes(command, ["area pequena", "papel pequeno"])) {
      applyVoicePaper("120x120");
      return;
    }

    if (commandIncludes(command, ["area mediana", "papel mediano"])) {
      applyVoicePaper("160x160");
      return;
    }

    if (commandIncludes(command, ["area grande", "papel grande"])) {
      applyVoicePaper("200x200");
      return;
    }

    if (commandIncludes(command, ["actualizar camara", "actualizar camaras", "buscar camara", "buscar camaras"])) {
      voiceFeedback("Actualizando cámaras.");
      await loadCameras();
      return;
    }

    if (commandIncludes(command, ["capturar", "tomar foto", "sacar foto", "foto"])) {
      if (!cameraScreen.classList.contains("active")) {
        setVoiceStatus("Primero di: continuar a cámara.", "error");
        return;
      }

      setVoiceStatus("Capturando foto por voz.", "ok");
      stopVoiceListening(false);
      await handleCapture();
      return;
    }

    if (commandIncludes(command, ["continuar", "camara", "ir a camara"])) {
      voiceFeedback("Abriendo cámara.");
      await handleContinueToCamera();
      return;
    }

    if (commandIncludes(command, ["gira", "girar", "ruleta", "sortea", "personaje"])) {
      voiceFeedback("Girando ruleta.");
      await spinRoulette();
      return;
    }

    if (commandIncludes(command, ["modo museo", "museo"])) {
      voiceFeedback("Activando modo museo. No giraré la ruleta hasta que lo pidas.");
      stopVoiceListening(false);
      await runMuseumMode({ resumeVoice: true });
      return;
    }

    if (commandIncludes(command, ["demo wro", "demo", "iniciar demo", "demostracion"])) {
      voiceFeedback("Iniciando demo WRO.");
      await runWroDemo();
      return;
    }

    if (commandIncludes(command, ["gcode", "codigo", "coordenadas"])) {
      voiceFeedback("Generando GCode existente.");
      await handleLastGcode({ preventDefault() {} });
      return;
    }

    setVoiceStatus("No entendí ese comando. Di ayuda para ver ejemplos.", "error");
  } catch (error) {
    console.error(error);
    setVoiceStatus(error.message || "No pude ejecutar el comando de voz.", "error");
  } finally {
    setTimeout(() => {
      voiceCommandBusy = false;
    }, 700);
  }
}

function missionMatches(personaje) {
  if (selectedMission === "sorpresa") {
    return true;
  }

  const category = normalizeText(personaje.categoria);

  if (selectedMission === "musica") {
    return category.includes("musica");
  }

  if (selectedMission === "arte") {
    return category.includes("arte") || category.includes("literatura");
  }

  if (selectedMission === "historia") {
    return category.includes("historia")
      || category.includes("liderazgo")
      || category.includes("humor");
  }

  if (selectedMission === "ciencia") {
    return category.includes("ciencia") || category.includes("tecnologia");
  }

  if (selectedMission === "deporte") {
    return category.includes("deporte");
  }

  return true;
}

function classifyRegion(personaje) {
  const text = normalizeText(`${personaje.region} ${personaje.historia_ia} ${personaje.nombre}`);

  if (text.includes("caribe")
    || text.includes("barranquilla")
    || text.includes("santa marta")
    || text.includes("cesar")
    || text.includes("bolivar")) {
    return "caribe";
  }

  if (text.includes("pacifico") || text.includes("cauca")) {
    return "pacifico";
  }

  if (text.includes("amazonia") || text.includes("amazonas") || text.includes("putumayo")) {
    return "amazonia";
  }

  if (text.includes("orinoquia") || text.includes("llano") || text.includes("arauca") || text.includes("meta")) {
    return "orinoquia";
  }

  return "andina";
}

function regionMatches(personaje) {
  if (selectedRegion === "todo") {
    return true;
  }

  return classifyRegion(personaje) === selectedRegion;
}

function getFilteredCharacters() {
  const filtered = allCharacters.filter((personaje) => missionMatches(personaje) && regionMatches(personaje));

  if (filtered.length > 0) {
    return filtered;
  }

  return allCharacters.filter(missionMatches);
}

function updateFilterStatus() {
  if (!filterStatus || allCharacters.length === 0) {
    return;
  }

  const filtered = allCharacters.filter((personaje) => missionMatches(personaje) && regionMatches(personaje));
  const fallback = getFilteredCharacters();
  const missionLabel = missionLabels[selectedMission] || "Sorpresa";
  const regionLabel = selectedRegion === "todo"
    ? "toda Colombia"
    : regionMap?.querySelector(`[data-region="${selectedRegion}"]`)?.textContent || selectedRegion;

  if (filtered.length === 0 && selectedRegion !== "todo") {
    filterStatus.textContent = `Aún no hay referentes cargados para ${regionLabel} en la misión ${missionLabel}; usaré ${fallback.length} referentes de esa misión.`;
    return;
  }

  filterStatus.textContent = `${fallback.length} referente(s) disponibles para ${missionLabel} en ${regionLabel}.`;
}

function renderRouletteWheel() {
  const pool = getFilteredCharacters();
  const size = Math.max(pool.length, 1);
  const slice = 360 / size;

  const stops = pool
    .map((_, index) => {
      const start = index * slice;
      const end = (index + 1) * slice;
      return `${rouletteColors[index % rouletteColors.length]} ${start}deg ${end}deg`;
    })
    .join(", ");
  rouletteWheel.style.background = `conic-gradient(${stops})`;

  rouletteMarkers.innerHTML = "";

  pool.forEach((_, index) => {
    const marker = document.createElement("span");
    marker.style.transform = `rotate(${index * slice}deg)`;
    rouletteMarkers.appendChild(marker);
  });
}

function getGcodeSettings() {
  const [ancho, alto] = paperSizeSelect.value.split("x").map((value) => Number(value));
  const accessibilityMode = accessibilityModeSelect?.value || "normal";
  const adjustedFeedrate = accessibilityMode === "relief"
    ? Math.min(Number(feedrateRange.value) || 1200, 900)
    : Number(feedrateRange.value) || 1200;

  return {
    ancho_mm: ancho || 160,
    alto_mm: alto || 160,
    feedrate: adjustedFeedrate,
    pen_mode: penModeSelect.value || "z",
    accessibility_mode: accessibilityMode,
  };
}

function gcodeSettingsQuery() {
  return new URLSearchParams(getGcodeSettings()).toString();
}

function syncMachineControls() {
  const settings = getGcodeSettings();
  feedrateValue.textContent = String(settings.feedrate);
  lastGcodeButton.href = `/api/descargar-gcode-ultima-caricatura?${gcodeSettingsQuery()}`;
}

function updateMissionButtons() {
  missionButtons?.querySelectorAll(".mission-button").forEach((button) => {
    button.classList.toggle("active", button.dataset.mission === selectedMission);
  });
}

function updateRegionButtons() {
  regionMap?.querySelectorAll(".region-button").forEach((button) => {
    button.classList.toggle("active", button.dataset.region === selectedRegion);
  });
}

function refreshCulturalFilters() {
  updateMissionButtons();
  updateRegionButtons();
  updateFilterStatus();
  renderRouletteWheel();

  if (!selectedCharacter) {
    rouletteName.textContent = "Presiona girar";
    rouletteBio.textContent = "La ruleta elegirá una figura cultural según tu misión.";
    rouletteFact.textContent = "El filtro ayuda a explicar que el robot no dibuja al azar: cuenta una historia cultural.";
    rouletteMeta.innerHTML = "";
    rouletteCenter.textContent = "?";
    museumCard?.classList.add("hidden");
    audioStoryButton.disabled = true;
    continueButton.disabled = true;
  }
}

function resetExperienceView() {
  experienceRunId += 1;
  setProcessingStage(-1);

  if (processSteps) {
    processSteps.querySelectorAll(".process-step").forEach((step) => {
      step.classList.remove("active", "done");
    });
  }

  if (robotAnimationFrame) {
    cancelAnimationFrame(robotAnimationFrame);
    robotAnimationFrame = null;
  }

  if (robotSim) {
    robotSim.classList.add("hidden");
  }

  if (robotBar) {
    robotBar.style.width = "0%";
  }

  if (robotPercent) {
    robotPercent.textContent = "0%";
  }

  if (robotStatus) {
    robotStatus.textContent = "Esperando GCode...";
  }
}

function setProcessStep(activeIndex) {
  if (!processSteps) {
    return;
  }

  processSteps.querySelectorAll(".process-step").forEach((step, index) => {
    step.classList.toggle("done", index < activeIndex);
    step.classList.toggle("active", index === activeIndex);
  });
}

function renderRobotStatus(percent, stats) {
  const contourCount = stats?.contornos_usados ?? "-";
  const pointCount = stats?.puntos_totales ?? "-";

  if (percent < 15) {
    return "Calibrando el área de dibujo y levantando el lápiz...";
  }

  if (percent < 45) {
    return `Leyendo ${contourCount} contornos detectados con OpenCV...`;
  }

  if (percent < 80) {
    return `Convirtiendo ${pointCount} puntos en movimientos del robot...`;
  }

  if (percent < 100) {
    return "Ejecutando el trazo final como lo haría el plotter...";
  }

  return "Simulación completa. El GCode ya está listo para la máquina.";
}

function runRobotSimulation(stats = {}) {
  if (!robotSim || !robotBar || !robotPercent || !robotStatus) {
    return;
  }

  if (robotAnimationFrame) {
    cancelAnimationFrame(robotAnimationFrame);
  }

  robotSim.classList.remove("hidden");
  robotBar.style.width = "0%";
  robotPercent.textContent = "0%";
  robotStatus.textContent = "Preparando simulación del robot...";

  const moves = Number(stats.movimientos_dibujo || stats.puntos_totales || 120);
  const duration = Math.min(6500, Math.max(3200, moves * 18));
  const start = performance.now();

  function tick(now) {
    const elapsed = now - start;
    const rawProgress = Math.min(elapsed / duration, 1);
    const easedProgress = 1 - Math.pow(1 - rawProgress, 3);
    const percent = Math.round(easedProgress * 100);

    robotBar.style.width = `${percent}%`;
    robotPercent.textContent = `${percent}%`;
    robotStatus.textContent = renderRobotStatus(percent, stats);

    if (rawProgress < 1) {
      robotAnimationFrame = requestAnimationFrame(tick);
      return;
    }

    robotAnimationFrame = null;
  }

  robotAnimationFrame = requestAnimationFrame(tick);
}

async function playResultTimeline(stats = {}) {
  const runId = experienceRunId;

  for (let index = 0; index < 5; index++) {
    if (runId !== experienceRunId) {
      return;
    }

    setProcessStep(index);

    if (index === 4) {
      runRobotSimulation(stats);
    }

    await sleep(index === 4 ? 300 : 520);
  }
}

function appendDownloadLink(url, text) {
  if (!url) {
    return;
  }

  const gcodeLink = document.createElement("a");
  gcodeLink.className = "secondary-button result-download";
  gcodeLink.href = url;
  gcodeLink.download = "";
  gcodeLink.textContent = text;

  resultBio.appendChild(document.createElement("br"));
  resultBio.appendChild(gcodeLink);
}

function renderCulturalPassport(result, options = {}) {
  if (!culturalPassport) {
    return;
  }

  const character = options.character || selectedCharacter;
  const statsMode = result?.gcode_stats?.accessibility_mode;
  const currentMode = statsMode || getGcodeSettings().accessibility_mode;
  const characterName = character?.nombre || result?.nombre || "Obra cultural";
  const region = character?.region || "Colombia";
  const modeLabel = accessibilityLabels[currentMode] || "Trazo normal";
  const missionLabel = missionLabels[selectedMission] || "Sorpresa";
  const qrParams = new URLSearchParams({
    personaje: characterName,
    region,
    mision: missionLabel,
    modo: modeLabel,
  });
  const qrUrl = `/api/qr-cultural?${qrParams.toString()}`;

  passportCharacter.textContent = characterName;
  passportRegion.textContent = region;
  passportMode.textContent = modeLabel;

  if (passportQr && passportQrLink) {
    passportQr.src = qrUrl;
    passportQrLink.href = qrUrl;
  }

  renderAccessibilityNote(currentMode);
  culturalPassport.classList.remove("hidden");
}

function renderAccessibilityNote(mode) {
  if (!accessibilityNote) {
    return;
  }

  const notes = {
    normal: "Modo normal: genera una obra visual de línea limpia para marcador o lápiz.",
    high_contrast: "Alto contraste: aumenta la fuerza del contorno para facilitar lectura visual y explicación técnica.",
    relief: "Relieve táctil: reduce la velocidad y repite el trazo para usar pintura espesa, silicona, pegante o marcador de relieve.",
  };

  accessibilityNote.textContent = notes[mode] || notes.normal;
  accessibilityNote.classList.remove("hidden");
}

async function startCamera() {
  stopCamera();

  const deviceId = cameraSelect.value;

  if (!deviceId) {
    cameraStatus.textContent = "Selecciona una cámara válida.";
    return false;
  }

  try {
    const constraints = {
      video: {
        deviceId: { exact: deviceId },
        width: { ideal: 1920 },
        height: { ideal: 1080 },
      },
      audio: false,
    };

    currentStream = await navigator.mediaDevices.getUserMedia(constraints);
    video.srcObject = currentStream;

    const selectedText = cameraSelect.options[cameraSelect.selectedIndex]?.textContent || "Cámara conectada";
    cameraLabel.textContent = selectedText;

    await video.play();

    return true;
  } catch (error) {
    console.error(error);
    cameraStatus.textContent = "No fue posible iniciar la cámara seleccionada.";
    return false;
  }
}

function stopCamera() {
  if (currentStream) {
    currentStream.getTracks().forEach((track) => track.stop());
    currentStream = null;
  }

  video.srcObject = null;
}

async function countdown() {
  countdownEl.classList.remove("hidden");

  for (let i = 5; i >= 1; i--) {
    countdownEl.textContent = String(i);
    playCountdownSound(i);
    await sleep(1000);
  }

  countdownEl.classList.add("hidden");
  playCameraSound();
}

function captureFrame() {
  const width = video.videoWidth || 1280;
  const height = video.videoHeight || 720;

  canvas.width = width;
  canvas.height = height;

  const ctx = canvas.getContext("2d");

  if (!ctx) {
    throw new Error("No fue posible preparar el canvas de captura.");
  }

  // Como el video se muestra en espejo con CSS, reflejamos también la captura.
  ctx.translate(width, 0);
  ctx.scale(-1, 1);
  ctx.drawImage(video, 0, 0, width, height);

  return canvas.toDataURL("image/png");
}

async function generateCaricature(imageData) {
  setProcessingStage(1);
  processingText.textContent = "Generando caricatura con IA...";

  const response = await fetch("/api/generar", {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
    },
    body: JSON.stringify({
      image_data: imageData,
      gender: selectedGender,
      personaje: selectedCharacter?.nombre || "",
      mission: selectedMission,
      ...getGcodeSettings(),
    }),
  });

  const data = await response.json();

  if (!response.ok) {
    throw new Error(data.detail || "Error generando la caricatura.");
  }

  return data;
}

function renderSelectedCharacter(personaje) {
  rouletteName.textContent = personaje.nombre;
  rouletteMeta.innerHTML = "";

  [personaje.categoria, personaje.region].filter(Boolean).forEach((value) => {
    const chip = document.createElement("span");
    chip.textContent = value;
    rouletteMeta.appendChild(chip);
  });

  rouletteBio.textContent = personaje.bio_display;
  rouletteFact.textContent = personaje.dato_cultural || "Este personaje hace parte de la memoria cultural colombiana.";
  rouletteCenter.textContent = shortName(personaje.nombre);
  renderMuseumCard(personaje);
  rouletteName.classList.add("roulette-selected");

  setTimeout(() => {
    rouletteName.classList.remove("roulette-selected");
  }, 500);
}

function renderMuseumCard(personaje) {
  if (!museumCard) {
    return;
  }

  museumTitle.textContent = personaje.nombre;
  museumCategory.textContent = personaje.categoria || "Cultura colombiana";
  museumRegion.textContent = personaje.region || "Colombia";
  museumMission.textContent = missionLabels[selectedMission] || "Sorpresa";
  museumImpact.textContent = `La obra conecta el rostro del participante con ${personaje.nombre} para compartir ${personaje.dato_cultural || "un aporte cultural colombiano"}.`;
  audioStoryButton.disabled = false;
  setAudioStatus("Personaje listo. Puedes probar sonido o escuchar la historia.");
  museumCard.classList.remove("hidden");
}

function renderGcodeStats(stats) {
  if (!stats || Object.keys(stats).length === 0) {
    gcodeStats.classList.add("hidden");
    gcodeStats.innerHTML = "";
    return;
  }

  const estimatedMinutes = stats.tiempo_estimado_min
    ? `${stats.tiempo_estimado_min} min`
    : "-";

  const items = [
    ["Método", stats.metodo || "OpenCV"],
    ["Área", stats.area_dibujo_mm ? `${stats.area_dibujo_mm.ancho} x ${stats.area_dibujo_mm.alto} mm` : "-"],
    ["Lápiz", stats.pen_mode || "-"],
    ["Accesibilidad", accessibilityLabels[stats.accessibility_mode] || "Trazo normal"],
    ["Velocidad", stats.feedrate || "-"],
    ["Tiempo estimado", estimatedMinutes],
    ["Contornos usados", stats.contornos_usados ?? "-"],
    ["Puntos convertidos", stats.puntos_totales ?? "-"],
    ["Movimientos de dibujo", stats.movimientos_dibujo ?? "-"],
    ["Líneas GCode", stats.lineas_gcode ?? "-"],
  ];

  gcodeStats.innerHTML = items
    .map(([label, value]) => `
      <div class="gcode-stat">
        <span>${label}</span>
        <strong>${value}</strong>
      </div>
    `)
    .join("");
  gcodeStats.classList.remove("hidden");
}

async function renderAnimatedTrace(previewUrl) {
  if (!gcodeTrace || !previewUrl) {
    return false;
  }

  try {
    const response = await fetch(`${previewUrl}?t=${Date.now()}`);

    if (!response.ok) {
      throw new Error("No fue posible cargar la vista SVG.");
    }

    const svgText = await response.text();
    const parsed = new DOMParser().parseFromString(svgText, "image/svg+xml");
    const svg = parsed.querySelector("svg");

    if (!svg) {
      throw new Error("La vista previa no contiene SVG.");
    }

    svg.classList.add("animated-trace");
    svg.removeAttribute("width");
    svg.removeAttribute("height");
    gcodeTrace.replaceChildren(svg);
    gcodeTrace.classList.remove("hidden");

    const drawable = svg.querySelectorAll("path, polyline, line");

    if (drawable.length === 0) {
      throw new Error("No se encontraron líneas para animar.");
    }

    drawable.forEach((shape, index) => {
      let length = 420;

      if (typeof shape.getTotalLength === "function") {
        try {
          length = Math.max(shape.getTotalLength(), 1);
        } catch (error) {
          length = 420;
        }
      }

      shape.classList.add("trace-line");
      shape.style.strokeDasharray = String(length);
      shape.style.strokeDashoffset = String(length);
      shape.style.animationDelay = `${Math.min(index * 55, 1800)}ms`;
    });

    gcodePreview.classList.add("hidden");
    return true;
  } catch (error) {
    console.warn(error);
    gcodeTrace.innerHTML = "";
    gcodeTrace.classList.add("hidden");
    return false;
  }
}

function renderGcodePreview(previewUrl) {
  if (!previewUrl) {
    gcodePreview.src = "";
    gcodePreview.classList.add("hidden");
    if (gcodeTrace) {
      gcodeTrace.innerHTML = "";
      gcodeTrace.classList.add("hidden");
    }
    return;
  }

  gcodePreview.src = `${previewUrl}?t=${Date.now()}`;
  gcodePreview.classList.remove("hidden");

  renderAnimatedTrace(previewUrl);
}

async function spinRoulette() {
  if (allCharacters.length === 0) {
    await loadCharacters();
  }

  const pool = getFilteredCharacters();

  if (pool.length === 0) {
    alert("No hay personajes disponibles para esta misión. Cambia el filtro e intenta de nuevo.");
    return;
  }

  playRouletteStartSound();
  spinButton.disabled = true;
  continueButton.disabled = true;
  selectedCharacter = null;
  selectedGender = null;
  rouletteWheel.classList.add("spinning");

  const vueltas = 24;

  for (let i = 0; i < vueltas; i++) {
    const personaje = pool[Math.floor(Math.random() * pool.length)];
    renderSelectedCharacter(personaje);
    playRouletteTick(i);
    await sleep(55 + i * 8);
  }

  selectedCharacter = pool[Math.floor(Math.random() * pool.length)];
  selectedGender = selectedCharacter.gender;

  const selectedIndex = pool.findIndex((personaje) => personaje.nombre === selectedCharacter.nombre);
  const slice = 360 / pool.length;
  const targetAngle = 360 - (selectedIndex * slice + slice / 2);
  wheelRotation += 1440 + targetAngle;
  rouletteWheel.style.transform = `rotate(${wheelRotation}deg)`;

  renderSelectedCharacter(selectedCharacter);

  await sleep(900);

  rouletteWheel.classList.remove("spinning");
  playRouletteWinSound();
  spinButton.disabled = false;
  continueButton.disabled = false;
}

function showGcodeResult(result, options = {}) {
  resetExperienceView();

  resultImage.src = result.resultado_url;
  resultTitle.textContent = options.title || "GCode listo";
  resultBio.textContent = options.bio || result.bio_display || result.mensaje || "Archivo listo para dibujar.";

  appendDownloadLink(result.gcode_url, options.downloadText || "Descargar GCode");
  renderCulturalPassport(result, options);
  renderGcodeStats(result.gcode_stats);
  renderGcodePreview(result.preview_url);

  showScreen(resultScreen);
  playSuccessSound();
  playResultTimeline(result.gcode_stats);
}

async function generateGcodeFromLastCaricature() {
  resetExperienceView();
  setProcessingStage(2);
  playProcessSound(2);
  processingText.textContent = "Generando GCode sin usar OpenAI...";
  showScreen(processingScreen);

  const data = await fetchGcodeFromLastCaricature();

  setProcessingStage(3);
  playProcessSound(3);
  showGcodeResult(data);
}

async function fetchGcodeFromLastCaricature() {
  const response = await fetch(`/api/gcode-ultima-caricatura?${gcodeSettingsQuery()}`);
  const data = await response.json();

  if (!response.ok) {
    throw new Error(data.detail || "No fue posible generar el GCode.");
  }

  return data;
}

async function runWroDemo() {
  try {
    demoWroButton.disabled = true;
    lastGcodeButton.classList.add("disabled-link");
    resetExperienceView();
    showScreen(processingScreen);

    const stages = [
      "1/5 Cultura colombiana: preparando el personaje inspirador...",
      "2/5 IA: usando la última caricatura generada, sin gastar OpenAI...",
      "3/5 OpenCV: detectando bordes y contornos principales...",
      "4/5 GCode: convirtiendo el dibujo en coordenadas para la máquina...",
      "5/5 Robot: preparando simulación del plotter...",
    ];

    for (let index = 0; index < 3; index++) {
      processingText.textContent = stages[index];
      setProcessingStage(index);
      playProcessSound(index);
      await sleep(650);
    }

    const data = await fetchGcodeFromLastCaricature();

    processingText.textContent = stages[3];
    setProcessingStage(3);
    playProcessSound(3);
    await sleep(700);

    processingText.textContent = stages[4];
    setProcessingStage(4);
    playProcessSound(4);
    await sleep(500);

    showGcodeResult(data, {
      title: "Demo Colombia en Trazos lista",
      bio: "La última obra ya fue convertida con OpenCV a trayectorias GCode para explicar cómo el robot transforma cultura colombiana en arte físico.",
      downloadText: "Descargar GCode de la demo",
      character: selectedCharacter,
    });
  } catch (error) {
    console.error(error);
    alert(error.message || "No fue posible iniciar la demo WRO. Primero genera una caricatura.");
    showScreen(selectionScreen);
  } finally {
    demoWroButton.disabled = false;
    lastGcodeButton.classList.remove("disabled-link");
  }
}

async function runMuseumMode(options = {}) {
  if (museumModeRunning) {
    return;
  }

  museumModeRunning = true;
  museumModeButton.disabled = true;
  demoWroButton.disabled = true;
  stopAudio();

  try {
    showScreen(selectionScreen);

    await speakTextAndWait(
      "Bienvenidos a Colombia en Trazos. Aquí no venimos solo a mirar una imagen: venimos a convertir identidad colombiana en arte físico con inteligencia artificial, OpenCV y un robot dibujante. Arranca la misión.",
      { rate: 1.03, pitch: 1.14, status: "Presentando modo museo WRO..." },
      8500
    );

    if (selectedCharacter) {
      await speakTextAndWait(
        `Ya tienes un personaje seleccionado: ${selectedCharacter.nombre}. Puedes decir escuchar historia, continuar a cámara, o demo WRO cuando quieras usar la última caricatura para explicar el GCode.`,
        { rate: 1.02, pitch: 1.12, status: "Modo museo esperando tu siguiente comando..." },
        7000
      );
    } else {
      await speakTextAndWait(
        "Ahora tú mandas la experiencia. Puedes decir: quiero música, Caribe, gira la ruleta, continuar a cámara, o demo WRO. No voy a girar ni abrir caricaturas hasta que tú lo pidas.",
        { rate: 1.02, pitch: 1.12, status: "Modo museo esperando tu siguiente comando..." },
        8500
      );
    }

    setVoiceStatus("Modo museo listo. Di: gira la ruleta, escuchar historia, continuar a cámara o demo WRO.", "ok");
  } catch (error) {
    console.error(error);
    alert(error.message || "No fue posible ejecutar el modo museo.");
    showScreen(selectionScreen);
  } finally {
    museumModeRunning = false;
    museumModeButton.disabled = false;
    demoWroButton.disabled = false;

    if (options.resumeVoice) {
      resumeVoiceListeningWhenQuiet(options.resumeDelayMs ?? VOICE_RESUME_DELAY_MS);
    }
  }
}

async function handleContinueToCamera() {
  if (!selectedCharacter) {
    alert("Primero gira la ruleta para escoger un personaje.");
    return;
  }

  const ok = await startCamera();

  if (!ok) {
    return;
  }

  showScreen(cameraScreen);
}

async function handleCapture() {
  try {
    captureButton.disabled = true;

    await countdown();

    const imageData = captureFrame();

    stopCamera();

    showScreen(processingScreen);
    setProcessingStage(0);

    const result = await generateCaricature(imageData);

    showGcodeResult(result, {
      title: `Obra cultural inspirada en ${result.nombre}`,
      bio: `${result.bio_display} La imagen fue transformada en una trayectoria para robot usando OpenCV y GCode.`,
      downloadText: "Descargar GCode de la obra",
      character: selectedCharacter,
    });
  } catch (error) {
    console.error(error);
    alert(error.message || "Ocurrió un error durante la captura.");
    showScreen(selectionScreen);
  } finally {
    captureButton.disabled = false;
  }
}

async function handleLastGcode(event) {
  event.preventDefault();

  try {
    lastGcodeButton.disabled = true;
    await generateGcodeFromLastCaricature();
  } catch (error) {
    console.error(error);
    alert(error.message || "No fue posible generar el GCode.");
    showScreen(selectionScreen);
  } finally {
    lastGcodeButton.disabled = false;
  }
}

function restart() {
  stopCamera();
  stopAudio();
  selectedGender = null;
  selectedCharacter = null;
  resultImage.src = "";
  resultTitle.textContent = "¡Retrato listo!";
  resultBio.textContent = "";
  renderGcodeStats(null);
  renderGcodePreview(null);
  resetExperienceView();
  culturalPassport?.classList.add("hidden");
  accessibilityNote?.classList.add("hidden");
  rouletteName.textContent = "Presiona girar";
  rouletteMeta.innerHTML = "";
  rouletteBio.textContent = "La ruleta elegirá una figura cultural según tu misión.";
  rouletteFact.textContent = "Colombia en Trazos une identidad, educación, accesibilidad y robótica.";
  rouletteCenter.textContent = "?";
  museumCard?.classList.add("hidden");
  audioStoryButton.disabled = true;
  setAudioStatus("Sonido listo para la experiencia.");
  setVoiceStatus("Di: “gira la ruleta”, “quiero música”, “modo museo” o “capturar”.");
  setVoiceTranscript("Esperando comando...");
  continueButton.disabled = true;
  showScreen(selectionScreen);
}

function handleMissionClick(event) {
  const button = event.target.closest(".mission-button");

  if (!button) {
    return;
  }

  selectedMission = button.dataset.mission || "sorpresa";
  selectedCharacter = null;
  selectedGender = null;
  refreshCulturalFilters();
  playButtonSound();
}

function handleRegionClick(event) {
  const button = event.target.closest(".region-button");

  if (!button) {
    return;
  }

  selectedRegion = button.dataset.region || "todo";
  selectedCharacter = null;
  selectedGender = null;
  refreshCulturalFilters();
  playButtonSound();
}

document.addEventListener("DOMContentLoaded", async () => {
  setTimeout(async () => {
    showScreen(selectionScreen);
    await Promise.all([loadCameras(), loadCharacters()]);
  }, 3000);

  refreshCamerasButton.addEventListener("click", loadCameras);
  captureButton.addEventListener("click", handleCapture);
  restartButton.addEventListener("click", restart);
  lastGcodeButton.addEventListener("click", handleLastGcode);
  demoWroButton.addEventListener("click", runWroDemo);
  museumModeButton.addEventListener("click", runMuseumMode);
  voiceCommandButton.addEventListener("click", startVoiceListening);
  voiceStopButton.addEventListener("click", () => stopVoiceListening());
  audioTestButton.addEventListener("click", playAudioPreview);
  audioStoryButton.addEventListener("click", speakSelectedCharacter);
  stopAudioButton.addEventListener("click", stopAudio);
  missionButtons.addEventListener("click", handleMissionClick);
  regionMap.addEventListener("click", handleRegionClick);
  spinButton.addEventListener("click", spinRoulette);
  continueButton.addEventListener("click", handleContinueToCamera);
  paperSizeSelect.addEventListener("change", syncMachineControls);
  penModeSelect.addEventListener("change", syncMachineControls);
  feedrateRange.addEventListener("input", syncMachineControls);
  accessibilityModeSelect.addEventListener("change", syncMachineControls);
  if ("speechSynthesis" in window) {
    refreshVoices();
    window.speechSynthesis.onvoiceschanged = () => {
      refreshVoices();
      setAudioStatus("Voz del navegador lista. Tambien tienes efectos sonoros.");
    };
  }

  if (!(window.SpeechRecognition || window.webkitSpeechRecognition)) {
    voiceCommandButton.disabled = true;
    voiceStopButton.disabled = true;
    setVoiceStatus("Control por voz no disponible en este navegador. Usa Chrome o Edge.", "error");
  }

  syncMachineControls();
});
