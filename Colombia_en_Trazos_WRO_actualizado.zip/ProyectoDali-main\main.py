from __future__ import annotations
from gcode_generator import generar_gcode_desde_archivo
import json
import os
import random
import traceback
from pathlib import Path
from typing import Any, Mapping, NotRequired, TypedDict, cast

from dotenv import load_dotenv
from fastapi import FastAPI, HTTPException, Response
from fastapi.responses import FileResponse, HTMLResponse
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel

from procesador import (
    generar_caricatura_con_referencia,
    guardar_captura_desde_data_url,
)


BASE_DIR = Path(__file__).resolve().parent
STATIC_DIR = BASE_DIR / "static"
ASSETS_DIR = BASE_DIR / "assets"
PERSONAJES_PATH = BASE_DIR / "personajes.json"

load_dotenv(BASE_DIR / ".env")

STATIC_DIR.mkdir(parents=True, exist_ok=True)
(STATIC_DIR / "capturas").mkdir(parents=True, exist_ok=True)
(STATIC_DIR / "resultados").mkdir(parents=True, exist_ok=True)


class Personaje(TypedDict):
    nombre: str
    historia_ia: str
    bio_display: str
    categoria: NotRequired[str]
    region: NotRequired[str]
    dato_cultural: NotRequired[str]


class GenerateRequest(BaseModel):
    image_data: str
    gender: str
    personaje: str | None = None
    mission: str | None = None
    ancho_mm: int = 160
    alto_mm: int = 160
    feedrate: int = 1200
    pen_mode: str = "z"
    accessibility_mode: str = "normal"


class GenerateResponse(TypedDict):
    ok: str
    nombre: str
    bio_display: str
    captura_url: str
    resultado_url: str
    gcode_url: str
    preview_url: str
    gcode_stats: dict[str, Any]


app = FastAPI(title="Colombia en Trazos")

app.mount("/static", StaticFiles(directory=str(STATIC_DIR)), name="static")
app.mount("/assets", StaticFiles(directory=str(ASSETS_DIR)), name="assets")


def leer_json_personajes() -> Mapping[str, Any]:
    with PERSONAJES_PATH.open("r", encoding="utf-8") as f:
        raw_data: object = json.load(f)

    if not isinstance(raw_data, Mapping):
        return {}

    return cast(Mapping[str, Any], raw_data)


def normalizar_personaje(item: object) -> Personaje | None:
    if not isinstance(item, Mapping):
        return None

    item_map = cast(Mapping[str, Any], item)

    nombre = item_map.get("nombre")
    historia_ia = item_map.get("historia_ia")
    bio_display = item_map.get("bio_display")
    categoria = item_map.get("categoria")
    region = item_map.get("region")
    dato_cultural = item_map.get("dato_cultural")

    if (
        isinstance(nombre, str)
        and isinstance(historia_ia, str)
        and isinstance(bio_display, str)
    ):
        personaje: Personaje = {
            "nombre": nombre,
            "historia_ia": historia_ia,
            "bio_display": bio_display,
        }

        if isinstance(categoria, str):
            personaje["categoria"] = categoria

        if isinstance(region, str):
            personaje["region"] = region

        if isinstance(dato_cultural, str):
            personaje["dato_cultural"] = dato_cultural

        return personaje

    return None


def cargar_personajes() -> dict[str, list[Personaje]]:
    resultado: dict[str, list[Personaje]] = {
        "Hombre": [],
        "Mujer": [],
    }

    try:
        data = leer_json_personajes()

        for genero in ("Hombre", "Mujer"):
            lista_raw_object: object = data.get(genero, [])

            if not isinstance(lista_raw_object, list):
                continue

            lista_raw: list[object] = cast(list[object], lista_raw_object)

            personajes_genero: list[Personaje] = []

            for item_raw in lista_raw:
                personaje = normalizar_personaje(item_raw)

                if personaje is not None:
                    personajes_genero.append(personaje)

            resultado[genero] = personajes_genero

        return resultado

    except FileNotFoundError:
        print("No se encontró personajes.json")
        return resultado

    except json.JSONDecodeError as error:
        print(f"Error de formato en personajes.json: {error}")
        return resultado

    except Exception as error:
        print(f"Error cargando personajes: {error}")
        return resultado


def buscar_personaje_por_nombre(
    personajes: dict[str, list[Personaje]],
    nombre_buscado: str,
) -> Personaje | None:
    nombre_normalizado = nombre_buscado.strip().lower()

    for lista_personajes in personajes.values():
        for personaje in lista_personajes:
            if personaje["nombre"].strip().lower() == nombre_normalizado:
                return personaje

    return None


def leer_metadata_gcode(gcode_path: Path) -> dict[str, Any]:
    metadata_path = gcode_path.with_suffix(".json")

    if not metadata_path.exists():
        return {}

    try:
        with metadata_path.open("r", encoding="utf-8") as f:
            data = json.load(f)

        if isinstance(data, dict):
            return cast(dict[str, Any], data)
    except Exception as error:
        print(f"No se pudo leer metadata de GCode: {error}")

    return {}


def preview_url_desde_gcode(gcode_path: Path) -> str:
    return f"/static/gcode/{gcode_path.with_suffix('.svg').name}"


def normalizar_config_gcode(
    ancho_mm: int = 160,
    alto_mm: int = 160,
    feedrate: int = 1200,
    pen_mode: str = "z",
    accessibility_mode: str = "normal",
) -> dict[str, Any]:
    return {
        "ancho_mm": max(60, min(int(ancho_mm), 300)),
        "alto_mm": max(60, min(int(alto_mm), 300)),
        "feedrate": max(300, min(int(feedrate), 3000)),
        "pen_mode": pen_mode if pen_mode in {"z", "m3", "servo"} else "z",
        "accessibility_mode": accessibility_mode
        if accessibility_mode in {"normal", "high_contrast", "relief"}
        else "normal",
    }


def gf256_tables() -> tuple[list[int], list[int]]:
    exp = [0] * 512
    log = [0] * 256
    x = 1

    for i in range(255):
        exp[i] = x
        log[x] = i
        x <<= 1

        if x & 0x100:
            x ^= 0x11D

    for i in range(255, 512):
        exp[i] = exp[i - 255]

    return exp, log


GF_EXP, GF_LOG = gf256_tables()


def gf256_mul(a: int, b: int) -> int:
    if a == 0 or b == 0:
        return 0

    return GF_EXP[GF_LOG[a] + GF_LOG[b]]


def rs_generator_poly(degree: int) -> list[int]:
    result = [1]

    for i in range(degree):
        next_poly = [1, GF_EXP[i]]
        product = [0] * (len(result) + 1)

        for j, left in enumerate(result):
            product[j] ^= gf256_mul(left, next_poly[0])
            product[j + 1] ^= gf256_mul(left, next_poly[1])

        result = product

    return result


def rs_remainder(data: list[int], degree: int) -> list[int]:
    generator = rs_generator_poly(degree)
    result = data[:] + [0] * degree

    for i, value in enumerate(data):
        if value == 0:
            continue

        for j, generator_value in enumerate(generator):
            result[i + j] ^= gf256_mul(generator_value, value)

    return result[-degree:]


def qr_format_bits(mask: int) -> int:
    error_level_l = 1
    data = (error_level_l << 3) | mask
    bits = data << 10
    generator = 0x537

    for i in range(14, 9, -1):
        if bits & (1 << i):
            bits ^= generator << (i - 10)

    return ((data << 10) | bits) ^ 0x5412


def crear_qr_svg(texto: str) -> str:
    version = 5
    size = 17 + version * 4
    border = 4
    data_codewords = 108
    ecc_codewords = 26
    mask = 0
    payload = texto.encode("utf-8")[:106]
    bit_buffer: list[int] = []

    def append_bits(value: int, length: int) -> None:
        for i in range(length - 1, -1, -1):
            bit_buffer.append((value >> i) & 1)

    append_bits(0b0100, 4)
    append_bits(len(payload), 8)

    for byte in payload:
        append_bits(byte, 8)

    max_bits = data_codewords * 8
    append_bits(0, min(4, max_bits - len(bit_buffer)))

    while len(bit_buffer) % 8:
        bit_buffer.append(0)

    codewords = [
        int("".join(str(bit) for bit in bit_buffer[i:i + 8]), 2)
        for i in range(0, len(bit_buffer), 8)
    ]

    pad_bytes = [0xEC, 0x11]
    pad_index = 0

    while len(codewords) < data_codewords:
        codewords.append(pad_bytes[pad_index % 2])
        pad_index += 1

    codewords = codewords[:data_codewords]
    full_codewords = codewords + rs_remainder(codewords, ecc_codewords)
    data_bits = [
        (codeword >> i) & 1
        for codeword in full_codewords
        for i in range(7, -1, -1)
    ]

    modules: list[list[bool | None]] = [[None for _ in range(size)] for _ in range(size)]
    reserved = [[False for _ in range(size)] for _ in range(size)]

    def set_function(x: int, y: int, dark: bool) -> None:
        if 0 <= x < size and 0 <= y < size:
            modules[y][x] = dark
            reserved[y][x] = True

    def draw_finder(x: int, y: int) -> None:
        for dy in range(-1, 8):
            for dx in range(-1, 8):
                xx = x + dx
                yy = y + dy
                dark = (
                    0 <= dx <= 6
                    and 0 <= dy <= 6
                    and (
                        dx in {0, 6}
                        or dy in {0, 6}
                        or (2 <= dx <= 4 and 2 <= dy <= 4)
                    )
                )
                set_function(xx, yy, dark)

    def draw_alignment(cx: int, cy: int) -> None:
        for dy in range(-2, 3):
            for dx in range(-2, 3):
                distance = max(abs(dx), abs(dy))
                set_function(cx + dx, cy + dy, distance != 1)

    def reserve_format() -> None:
        for i in range(6):
            set_function(8, i, False)

        set_function(8, 7, False)
        set_function(8, 8, False)
        set_function(7, 8, False)

        for i in range(9, 15):
            set_function(14 - i, 8, False)

        for i in range(8):
            set_function(size - 1 - i, 8, False)

        for i in range(8, 15):
            set_function(8, size - 15 + i, False)

    draw_finder(0, 0)
    draw_finder(size - 7, 0)
    draw_finder(0, size - 7)
    draw_alignment(30, 30)

    for i in range(8, size - 8):
        set_function(6, i, i % 2 == 0)
        set_function(i, 6, i % 2 == 0)

    reserve_format()
    set_function(8, 4 * version + 9, True)

    bit_index = 0
    direction = -1
    row = size - 1
    col = size - 1

    while col > 0:
        if col == 6:
            col -= 1

        while True:
            for offset in range(2):
                x = col - offset

                if not reserved[row][x]:
                    bit = data_bits[bit_index] if bit_index < len(data_bits) else 0

                    if (x + row) % 2 == 0:
                        bit ^= 1

                    modules[row][x] = bit == 1
                    bit_index += 1

            row += direction

            if row < 0 or row >= size:
                row -= direction
                direction = -direction
                break

        col -= 2

    format_bits = qr_format_bits(mask)

    def get_bit(value: int, index: int) -> bool:
        return ((value >> index) & 1) != 0

    for i in range(6):
        set_function(8, i, get_bit(format_bits, i))

    set_function(8, 7, get_bit(format_bits, 6))
    set_function(8, 8, get_bit(format_bits, 7))
    set_function(7, 8, get_bit(format_bits, 8))

    for i in range(9, 15):
        set_function(14 - i, 8, get_bit(format_bits, i))

    for i in range(8):
        set_function(size - 1 - i, 8, get_bit(format_bits, i))

    for i in range(8, 15):
        set_function(8, size - 15 + i, get_bit(format_bits, i))

    canvas_size = size + border * 2
    rects = [
        f'<rect x="{x + border}" y="{y + border}" width="1" height="1" />'
        for y, row_modules in enumerate(modules)
        for x, dark in enumerate(row_modules)
        if dark
    ]

    return "\n".join([
        f'<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 {canvas_size} {canvas_size}" shape-rendering="crispEdges">',
        '<rect width="100%" height="100%" fill="white" />',
        '<g fill="#111827">',
        *rects,
        '</g>',
        '</svg>',
    ])


@app.get("/", response_class=HTMLResponse)
def index() -> str:
    index_path = STATIC_DIR / "index.html"

    if not index_path.exists():
        raise HTTPException(
            status_code=404,
            detail="No se encontró static/index.html",
        )

    return index_path.read_text(encoding="utf-8")


@app.get("/favicon.ico")
def favicon() -> dict[str, str]:
    return {"ok": "false"}


@app.get("/api/personajes")
def obtener_personajes() -> dict[str, list[Personaje]]:
    return cargar_personajes()


@app.get("/api/qr-cultural")
def qr_cultural(
    personaje: str = "Colombia en Trazos",
    region: str = "Colombia",
    mision: str = "Cultura",
    modo: str = "Trazo normal",
) -> Response:
    texto = (
        "Colombia en Trazos\n"
        f"P: {personaje}\n"
        f"R: {region}\n"
        f"M: {mision}\n"
        f"D: {modo}"
    )

    return Response(
        content=crear_qr_svg(texto),
        media_type="image/svg+xml",
    )


def obtener_ultima_caricatura_generada() -> Path:
    resultados_dir = STATIC_DIR / "resultados"
    imagenes = sorted(
        resultados_dir.glob("*.png"),
        key=lambda path: path.stat().st_mtime,
        reverse=True,
    )

    if not imagenes:
        raise HTTPException(
            status_code=404,
            detail="Todavia no hay caricaturas generadas.",
        )

    return imagenes[0]


@app.get("/api/gcode-ultima-caricatura")
def generar_gcode_ultima_caricatura(
    ancho_mm: int = 160,
    alto_mm: int = 160,
    feedrate: int = 1200,
    pen_mode: str = "z",
    accessibility_mode: str = "normal",
) -> dict[str, Any]:
    resultado_path = obtener_ultima_caricatura_generada()
    nombre_gcode = resultado_path.stem + ".gcode"
    config = normalizar_config_gcode(ancho_mm, alto_mm, feedrate, pen_mode, accessibility_mode)

    salida = generar_gcode_desde_archivo(
        imagen_path=resultado_path,
        nombre_salida=nombre_gcode,
        **config,
    )

    return {
        "ok": "true",
        "mensaje": "GCode generado desde la ultima caricatura guardada",
        "resultado_url": f"/static/resultados/{resultado_path.name}",
        "gcode_url": f"/static/gcode/{nombre_gcode}",
        "preview_url": preview_url_desde_gcode(salida),
        "archivo": str(salida),
        "gcode_stats": leer_metadata_gcode(salida),
    }


@app.get("/api/descargar-gcode-ultima-caricatura")
def descargar_gcode_ultima_caricatura(
    ancho_mm: int = 160,
    alto_mm: int = 160,
    feedrate: int = 1200,
    pen_mode: str = "z",
    accessibility_mode: str = "normal",
) -> FileResponse:
    resultado_path = obtener_ultima_caricatura_generada()
    nombre_gcode = resultado_path.stem + ".gcode"
    config = normalizar_config_gcode(ancho_mm, alto_mm, feedrate, pen_mode, accessibility_mode)

    salida = generar_gcode_desde_archivo(
        imagen_path=resultado_path,
        nombre_salida=nombre_gcode,
        **config,
    )

    return FileResponse(
        path=str(salida),
        media_type="text/plain",
        filename=nombre_gcode,
    )


@app.get("/api/gcode-prueba")
def generar_gcode_prueba(
    ancho_mm: int = 160,
    alto_mm: int = 160,
    feedrate: int = 1200,
    pen_mode: str = "z",
    accessibility_mode: str = "normal",
) -> dict[str, Any]:
    imagen_prueba = ASSETS_DIR / "silueta.png"
    config = normalizar_config_gcode(ancho_mm, alto_mm, feedrate, pen_mode, accessibility_mode)

    salida = generar_gcode_desde_archivo(
        imagen_path=imagen_prueba,
        nombre_salida="prueba_silueta.gcode",
        **config,
    )

    return {
        "ok": "true",
        "mensaje": "GCode generado correctamente",
        "gcode_url": "/static/gcode/prueba_silueta.gcode",
        "preview_url": preview_url_desde_gcode(salida),
        "archivo": str(salida),
        "gcode_stats": leer_metadata_gcode(salida),
    }

@app.post("/api/generar")
def generar_caricatura(payload: GenerateRequest) -> GenerateResponse:
    api_key = os.getenv("OPENAI_API_KEY")

    if not api_key:
        raise HTTPException(
            status_code=500,
            detail="No se encontró OPENAI_API_KEY en el archivo .env",
        )

    personajes = cargar_personajes()
    genero = payload.gender.strip()
    personaje_solicitado = (payload.personaje or "").strip()

    if personaje_solicitado:
        personaje = buscar_personaje_por_nombre(personajes, personaje_solicitado)

        if personaje is None:
            raise HTTPException(
                status_code=400,
                detail=f"No se encontró el personaje {personaje_solicitado}.",
            )
    else:
        if genero not in personajes:
            raise HTTPException(
                status_code=400,
                detail="Género no válido.",
            )

        lista_personajes = personajes[genero]

        if not lista_personajes:
            raise HTTPException(
                status_code=400,
                detail=f"No hay personajes configurados para {genero}.",
            )

        personaje = random.choice(lista_personajes)

    try:
        captura_relativa: str = guardar_captura_desde_data_url(payload.image_data)

        print(f"Captura guardada: static/{captura_relativa}")
        print(f"Generando caricatura con personaje: {personaje['nombre']}")

        resultado_relativo: str = generar_caricatura_con_referencia(
            captura_relativa=captura_relativa,
            personaje=personaje,
        )

        print(f"Resultado generado: static/{resultado_relativo}")

        resultado_path = STATIC_DIR / resultado_relativo
        nombre_gcode = Path(resultado_relativo).stem + ".gcode"
        config = normalizar_config_gcode(
            ancho_mm=payload.ancho_mm,
            alto_mm=payload.alto_mm,
            feedrate=payload.feedrate,
            pen_mode=payload.pen_mode,
            accessibility_mode=payload.accessibility_mode,
        )
        salida_gcode = generar_gcode_desde_archivo(
            imagen_path=resultado_path,
            nombre_salida=nombre_gcode,
            **config,
        )

        print(f"GCode generado: {salida_gcode}")

        return {
            "ok": "true",
            "nombre": personaje["nombre"],
            "bio_display": personaje["bio_display"],
            "captura_url": f"/static/{captura_relativa}",
            "resultado_url": f"/static/{resultado_relativo}",
            "gcode_url": f"/static/gcode/{nombre_gcode}",
            "preview_url": preview_url_desde_gcode(salida_gcode),
            "gcode_stats": leer_metadata_gcode(salida_gcode),
        }

    except Exception as error:
        print("\nERROR INTERNO EN /api/generar")
        print("--------------------------------")
        print(traceback.format_exc())
        print("--------------------------------\n")

        raise HTTPException(
            status_code=500,
            detail=f"Error generando caricatura: {error}",
        ) from error
