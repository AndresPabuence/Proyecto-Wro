from pathlib import Path
import json
import time

import cv2


BASE_DIR = Path(__file__).resolve().parent
STATIC_DIR = BASE_DIR / "static"
GCODE_DIR = STATIC_DIR / "gcode"


def comandos_lapicero(pen_mode: str) -> tuple[str, str, str]:
    if pen_mode == "m3":
        return (
            "M5 ; levantar/apagar lapicero",
            "M3 S255 ; bajar/activar lapicero",
            "M5",
        )

    if pen_mode == "servo":
        return (
            "M280 P0 S90 ; levantar lapicero con servo",
            "M280 P0 S30 ; bajar lapicero con servo",
            "M280 P0 S90",
        )

    return (
        "G0 Z5 ; levantar lapicero",
        "G1 Z0 ; bajar lapicero",
        "G0 Z5",
    )


def generar_gcode_desde_archivo(
    imagen_path: Path,
    nombre_salida: str = "dibujo.gcode",
    ancho_mm: int = 160,
    alto_mm: int = 160,
    feedrate: int = 1200,
    pen_mode: str = "z",
    accessibility_mode: str = "normal",
) -> Path:
    if not imagen_path.exists():
        raise FileNotFoundError(f"No existe la imagen: {imagen_path}")

    GCODE_DIR.mkdir(parents=True, exist_ok=True)
    ancho_mm = max(60, min(int(ancho_mm), 300))
    alto_mm = max(60, min(int(alto_mm), 300))
    feedrate = max(300, min(int(feedrate), 3000))
    pen_mode = pen_mode if pen_mode in {"z", "m3", "servo"} else "z"
    accessibility_mode = accessibility_mode if accessibility_mode in {"normal", "high_contrast", "relief"} else "normal"

    if accessibility_mode == "relief":
        feedrate = min(feedrate, 900)

    imagen = cv2.imread(str(imagen_path))

    if imagen is None:
        raise RuntimeError("No se pudo leer la imagen.")

    gris = cv2.cvtColor(imagen, cv2.COLOR_BGR2GRAY)
    gris = cv2.resize(gris, (ancho_mm, alto_mm))

    if accessibility_mode == "high_contrast":
        bordes = cv2.Canny(gris, 55, 150)
        stroke_width = 1.2
        preview_stroke = "#020617"
        pass_count = 1
    elif accessibility_mode == "relief":
        bordes = cv2.Canny(gris, 65, 155)
        stroke_width = 1.35
        preview_stroke = "#111827"
        pass_count = 2
    else:
        bordes = cv2.Canny(gris, 80, 180)
        stroke_width = 0.8
        preview_stroke = "#111827"
        pass_count = 1

    contornos, _ = cv2.findContours(
        bordes,
        cv2.RETR_EXTERNAL,
        cv2.CHAIN_APPROX_SIMPLE
    )

    salida_path = GCODE_DIR / nombre_salida

    escala = 1.0
    lapicero_arriba, lapicero_abajo, lapicero_final = comandos_lapicero(pen_mode)
    contornos_usados = 0
    puntos_totales = 0
    movimientos_dibujo = 0
    svg_polylines: list[str] = []

    lineas = [
        "; Proyecto Dali - GCode generado con OpenCV",
        f"; Imagen origen: {imagen_path.name}",
        "; Proceso: escala de grises -> Canny -> contornos -> coordenadas XY",
        f"; Resolucion de trabajo: {gris.shape[1]}x{gris.shape[0]} puntos",
        f"; Area de dibujo: {ancho_mm}x{alto_mm} mm",
        f"; Feedrate: {feedrate}",
        f"; Modo de lapicero: {pen_mode}",
        f"; Modo de accesibilidad: {accessibility_mode}",
        f"; Pasadas por trazo: {pass_count}",
        "G21 ; usar milimetros",
        "G90 ; coordenadas absolutas",
        lapicero_arriba,
    ]

    for contorno in contornos:
        if len(contorno) < 5:
            continue

        puntos = contorno.squeeze()

        if len(puntos.shape) != 2:
            continue

        contornos_usados += 1
        puntos_totales += len(puntos)
        svg_puntos = " ".join(
            f"{punto[0] * escala:.2f},{punto[1] * escala:.2f}"
            for punto in puntos
        )
        svg_polylines.append(
            f'<polyline points="{svg_puntos}" fill="none" stroke="{preview_stroke}" stroke-width="{stroke_width}" />'
        )

        for pass_index in range(pass_count):
            x0 = puntos[0][0] * escala
            y0 = puntos[0][1] * escala

            if pass_count > 1:
                lineas.append(f"; pasada {pass_index + 1} de {pass_count} para modo relieve")

            lineas.append(f"G0 X{x0:.2f} Y{y0:.2f}")
            lineas.append(lapicero_abajo)

            for punto in puntos[1:]:
                x = punto[0] * escala
                y = punto[1] * escala
                lineas.append(f"G1 X{x:.2f} Y{y:.2f} F{feedrate}")
                movimientos_dibujo += 1

            lineas.append(lapicero_arriba)

    lineas.extend([
        lapicero_final,
        "G0 X0 Y0",
        "M2 ; fin del programa",
    ])

    salida_path.write_text("\n".join(lineas), encoding="utf-8")
    preview_path = salida_path.with_suffix(".svg")
    preview_path.write_text(
        "\n".join(
            [
                f'<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 {ancho_mm} {alto_mm}">',
                '<rect width="100%" height="100%" fill="white" />',
                '<g stroke-linecap="round" stroke-linejoin="round">',
                *svg_polylines,
                "</g>",
                "</svg>",
            ]
        ),
        encoding="utf-8",
    )

    metadata = {
        "imagen_origen": str(imagen_path),
        "archivo_gcode": str(salida_path),
        "preview_svg": str(preview_path),
        "generado_en": int(time.time()),
        "metodo": "OpenCV Canny + findContours",
        "resolucion_trabajo": {
            "ancho": int(gris.shape[1]),
            "alto": int(gris.shape[0]),
        },
        "area_dibujo_mm": {
            "ancho": ancho_mm,
            "alto": alto_mm,
        },
        "contornos_detectados": len(contornos),
        "contornos_usados": contornos_usados,
        "puntos_totales": puntos_totales,
        "movimientos_dibujo": movimientos_dibujo,
        "lineas_gcode": len(lineas),
        "feedrate": feedrate,
        "escala": escala,
        "pen_mode": pen_mode,
        "accessibility_mode": accessibility_mode,
        "pasadas_por_trazo": pass_count,
        "tiempo_estimado_min": round(max(movimientos_dibujo / max(feedrate, 1), 0.2), 1),
        "comando_lapicero_arriba": lapicero_arriba,
        "comando_lapicero_abajo": lapicero_abajo,
    }

    salida_path.with_suffix(".json").write_text(
        json.dumps(metadata, ensure_ascii=False, indent=2),
        encoding="utf-8",
    )

    return salida_path
